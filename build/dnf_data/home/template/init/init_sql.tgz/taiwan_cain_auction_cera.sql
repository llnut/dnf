
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `auction_average_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_average_price` (
  `item_id` int(10) unsigned NOT NULL default '0',
  `upgrade` tinyint(3) unsigned NOT NULL default '0',
  `average_price` int(11) default NULL,
  `seperate_upgrade` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`item_id`,`upgrade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `auction_average_price` VALUES (2675336,0,200,0);
DROP TABLE IF EXISTS `auction_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history` (
  `auction_id` bigint(20) unsigned NOT NULL default '0',
  `start_time` datetime default NULL,
  `occ_time` datetime default NULL,
  `event_type` tinyint(4) default NULL,
  `owner_id` int(11) default NULL,
  `buyer_id` int(11) default NULL,
  `price` int(11) default NULL,
  `seal_flag` tinyint(4) default NULL,
  `item_id` int(10) unsigned default NULL,
  `add_info` int(11) default NULL,
  `upgrade` tinyint(3) unsigned default NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL default '0',
  `amplify_value` mediumint(8) unsigned NOT NULL default '0',
  `seal_cnt` tinyint(3) unsigned default NULL,
  `endurance` smallint(5) unsigned default NULL,
  `extend_info` int(10) unsigned default NULL,
  `owner_postal_id` int(10) unsigned default NULL,
  `buyer_postal_id` int(10) unsigned default NULL,
  `unit_price` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`auction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_history_buyer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_history_buyer` (
  `auction_id` bigint(20) unsigned default NULL,
  `occ_time` datetime default NULL,
  `pre_buyer_id` int(11) default NULL,
  `buyer_id` int(11) default NULL,
  `pre_price` int(11) default NULL,
  `price` int(11) default NULL,
  `pre_buyer_postal_id` int(10) unsigned default NULL,
  `commission` int(11) unsigned NOT NULL default '0',
  KEY `idx_auction_id` USING BTREE (`auction_id`),
  KEY `idx_buyer_id` USING BTREE (`buyer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_main` (
  `auction_id` bigint(20) NOT NULL default '0',
  `occ_time` datetime default NULL,
  `expire_time` int(11) default NULL,
  `owner_id` int(11) default NULL,
  `owner_name` varchar(20) default NULL,
  `owner_type` tinyint(4) NOT NULL default '0',
  `owner_nexon_id` varchar(25) NOT NULL default '',
  `buyer_id` int(11) default NULL,
  `buyer_name` varchar(20) default NULL,
  `price` bigint(20) default NULL,
  `instant_price` bigint(20) default NULL,
  `seal_flag` tinyint(3) unsigned default NULL,
  `item_id` int(10) unsigned default NULL,
  `add_info` int(11) default NULL,
  `upgrade` tinyint(3) unsigned default NULL,
  `amplify_option` tinyint(3) unsigned NOT NULL default '0',
  `amplify_value` mediumint(8) unsigned NOT NULL default '0',
  `seal_cnt` tinyint(3) unsigned default NULL,
  `endurance` smallint(5) unsigned default NULL,
  `extend_info` int(10) unsigned default NULL,
  `black_point` int(10) unsigned NOT NULL default '0',
  `unit_price` int(11) default NULL,
  `random_option` varchar(14) NOT NULL default '',
  `roi_high_key` bigint(20) NOT NULL default '0',
  `roi_low_key` int(11) NOT NULL default '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL default '0',
  `item_guid` varbinary(10) NOT NULL default '',
  PRIMARY KEY  (`auction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_manual_average_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_manual_average_price` (
  `no` int(11) unsigned NOT NULL auto_increment,
  `item_id` int(11) unsigned NOT NULL default '0',
  `upgrade` tinyint(4) unsigned NOT NULL default '0',
  `average_price` int(11) unsigned NOT NULL default '0',
  `is_apply` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`no`),
  KEY `idx_serverid_isapply` USING BTREE (`is_apply`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_roi_average_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_roi_average_price` (
  `no` int(10) unsigned NOT NULL auto_increment,
  `item_id` int(10) unsigned NOT NULL default '0',
  `upgrade` tinyint(3) unsigned NOT NULL default '0',
  `roi_high_key` bigint(20) NOT NULL default '0',
  `roi_low_key` int(10) unsigned NOT NULL default '0',
  `roi_index1` smallint(5) unsigned NOT NULL default '0',
  `roi_index2` smallint(5) unsigned NOT NULL default '0',
  `roi_index3` smallint(5) unsigned NOT NULL default '0',
  `average_price` int(10) unsigned NOT NULL default '0',
  `real_purchase_count` mediumint(8) unsigned NOT NULL default '0',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`no`),
  UNIQUE KEY `item_id` (`item_id`,`upgrade`,`roi_high_key`,`roi_low_key`,`roi_index1`,`roi_index2`,`roi_index3`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_roi_constraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_roi_constraint` (
  `db_inf_max_price` int(10) unsigned NOT NULL default '0',
  `db_inf_min_price` int(10) unsigned NOT NULL default '0',
  `db_inf_prob` int(10) unsigned NOT NULL default '0',
  `db_inf_limit_count` int(10) unsigned NOT NULL default '0',
  `db_inf_base_mul_min_a` int(10) unsigned NOT NULL default '0',
  `db_inf_base_mul_max_b` int(10) unsigned NOT NULL default '0',
  `last_update_date` date NOT NULL default '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_system_iteminfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_system_iteminfo` (
  `sys_auction_id` int(11) default '0',
  `probability` smallint(5) unsigned default '0',
  `price` int(11) default '0',
  `seal_flag` tinyint(3) unsigned default '0',
  `item_id` int(10) unsigned default '0',
  `add_info` int(11) default '0',
  `upgrade` tinyint(3) unsigned default '0',
  `seal_cnt` tinyint(3) unsigned default '0',
  `endurance` smallint(5) unsigned default '0',
  `extend_info` int(10) unsigned default '0',
  KEY `idx1` USING BTREE (`sys_auction_id`,`item_id`),
  KEY `idx2` USING BTREE (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `auction_system_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction_system_main` (
  `sys_auction_id` int(11) NOT NULL auto_increment,
  `occ_time` datetime default '0000-00-00 00:00:00',
  `regist_interval` int(11) default '0',
  `regist_time` time default '00:00:00',
  `start_date` date default '0000-00-00',
  `end_date` date default '0000-00-00',
  `expire_interval` smallint(5) unsigned default '0',
  `last_auction_time` datetime default '0000-00-00 00:00:00',
  `expected_regist_time` time default '00:00:00',
  PRIMARY KEY  (`sys_auction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

