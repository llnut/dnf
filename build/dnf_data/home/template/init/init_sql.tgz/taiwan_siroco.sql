
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `BID` int(11) NOT NULL auto_increment,
  `BUID` int(11) NOT NULL,
  `BMac_md5` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`BID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `member_play_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_play_info` (
  `MID` int(11) NOT NULL auto_increment,
  `m_id` int(11) NOT NULL,
  `play_count` int(11) NOT NULL,
  `charac_num` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `last_login_time` datetime default NULL,
  `mac_addr` varchar(50) NOT NULL,
  `ap_number` varchar(50) NOT NULL,
  `sims` varchar(50) NOT NULL,
  `reg_time` date NOT NULL,
  `charac_no` int(11) NOT NULL,
  `charac_name` varchar(20) NOT NULL,
  `state` tinyint(4) NOT NULL,
  PRIMARY KEY  (`MID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `new_cdk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_cdk` (
  `CID` int(11) NOT NULL auto_increment COMMENT 'ç¼–å·',
  `CIMEI` int(11) NOT NULL COMMENT 'CDKç¼–å·',
  `CRenum` int(11) NOT NULL COMMENT 'åŒä¸€ç”¨æˆ·é¢†å–æ¬¡æ•°',
  `CTitle` varchar(50) NOT NULL default '' COMMENT 'CDKæ ‡é¢˜',
  `CCdk` varchar(50) NOT NULL COMMENT 'CDKå†…å®¹',
  `CCode` varchar(100) NOT NULL COMMENT 'ç‰©å“ä»£ç ',
  `CNumber` varchar(100) NOT NULL COMMENT 'ç‰©å“æ•°é‡',
  `CStreng` varchar(100) NOT NULL COMMENT 'å¼ºåŒ–',
  `CForging` varchar(100) NOT NULL COMMENT 'é”»é€ ',
  `CRedtype` varchar(100) NOT NULL COMMENT 'çº¢å­—ç±»åž‹',
  `CRednum` varchar(100) NOT NULL COMMENT 'çº¢å­—æ•°å€¼',
  `CLock` varchar(100) NOT NULL COMMENT 'æ˜¯å¦å°è£…',
  `CGold` int(11) NOT NULL COMMENT 'é‡‘å¸',
  `CReward` int(11) NOT NULL COMMENT 'é¢†å–ç¤¼åŒ…çš„UID',
  PRIMARY KEY  (`CID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `waigua_feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `waigua_feature` (
  `m_id` int(11) NOT NULL,
  `charac_name` varchar(20) NOT NULL,
  `kaigua_time` datetime NOT NULL,
  `test_method` int(11) NOT NULL,
  `kaigua_feature` varchar(256) NOT NULL,
  `state` int(11) NOT NULL default '0',
  PRIMARY KEY  (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `zhanli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhanli` (
  `ZID` int(11) NOT NULL auto_increment,
  `ZName` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `ZLZ` int(100) NOT NULL,
  `ZDJ` int(100) NOT NULL,
  PRIMARY KEY  (`ZID`)
) ENGINE=InnoDB DEFAULT CHARSET=big5 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `zhanli_Hei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhanli_Hei` (
  `ZID` int(11) NOT NULL auto_increment,
  `HID` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`ZID`)
) ENGINE=InnoDB DEFAULT CHARSET=big5 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

