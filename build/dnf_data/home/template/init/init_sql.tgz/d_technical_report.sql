
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accessibility_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessibility_stat` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `main_type` tinyint(3) unsigned NOT NULL default '0',
  `sub_type` smallint(5) unsigned NOT NULL default '0',
  `val` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`main_type`,`sub_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `assert_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assert_manager` (
  `file_name` varchar(255) NOT NULL default '',
  `file_line` smallint(5) unsigned NOT NULL default '0',
  `reason` varchar(255) NOT NULL default '',
  `cnt` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`file_name`,`file_line`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `captcha_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_info` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `total_try_count` int(10) unsigned NOT NULL default '0',
  `success_count` int(10) unsigned NOT NULL default '0',
  `fail_count` int(10) unsigned NOT NULL default '0',
  `block_count` int(10) unsigned NOT NULL default '0',
  `incomplete_request_count` int(10) unsigned NOT NULL default '0',
  `invalid_request_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_occ_time` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `captcha_invalid_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_invalid_request` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `m_id` int(10) unsigned NOT NULL default '0',
  `request_type` smallint(5) unsigned NOT NULL default '0',
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `idx_m_id` USING BTREE (`m_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `captcha_invalid_request_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_invalid_request_type` (
  `type` smallint(5) unsigned NOT NULL auto_increment,
  `type_desc` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `challenge_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_lag_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL default '0',
  `min_fps` smallint(6) NOT NULL default '0',
  `avg_fps` smallint(6) NOT NULL default '0',
  `max_fps` smallint(6) NOT NULL default '0',
  `win_fps` smallint(6) NOT NULL default '0',
  `full_fps` smallint(6) NOT NULL default '0',
  `full_win_fps` smallint(6) NOT NULL default '0',
  `full_win_nosync_fps` smallint(6) NOT NULL default '0',
  `frame1` int(11) NOT NULL default '0',
  `time1` float(7,3) NOT NULL default '0.000',
  `frame2` int(11) NOT NULL default '0',
  `time2` float(7,3) NOT NULL default '0.000',
  `frame3` int(11) NOT NULL default '0',
  `time3` float(7,3) NOT NULL default '0.000',
  `frame4` int(11) NOT NULL default '0',
  `time4` float(7,3) NOT NULL default '0.000',
  `frame5` int(11) NOT NULL default '0',
  `time5` float(7,3) NOT NULL default '0.000',
  `frame6` int(11) NOT NULL default '0',
  `time6` float(7,3) NOT NULL default '0.000',
  `share_rate` int(10) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `challenge_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `challenge_lag_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `win_fps` int(10) unsigned NOT NULL default '0',
  `win_fps_cnt` int(11) NOT NULL default '0',
  `full_fps` int(10) unsigned NOT NULL default '0',
  `full_fps_cnt` int(11) NOT NULL default '0',
  `full_win_fps` int(10) unsigned NOT NULL default '0',
  `full_win_fps_cnt` int(11) NOT NULL default '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL default '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `collect_interval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collect_interval` (
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `value` smallint(5) unsigned default '60'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `common_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime default NULL,
  `server_group` tinyint(4) NOT NULL default '0',
  `share_rate` int(10) unsigned default NULL,
  `crash_count` smallint(5) unsigned default NULL,
  `village_to_dungeon_lag` smallint(6) NOT NULL default '0',
  `dungeon_to_village_lag` smallint(6) NOT NULL default '0',
  `crash_village` smallint(5) unsigned NOT NULL default '0',
  `crash_dungeon` smallint(5) unsigned NOT NULL default '0',
  `crash_challenge` smallint(5) unsigned NOT NULL default '0',
  `crash_wararea` smallint(5) unsigned NOT NULL default '0',
  `crash_fight_village` smallint(5) unsigned NOT NULL default '0',
  `crash_dead_tower` smallint(5) unsigned NOT NULL default '0',
  `crash_channel` smallint(5) unsigned NOT NULL default '0',
  `crash_chaos` smallint(5) unsigned NOT NULL default '0',
  `crash_load` smallint(5) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `common_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `server_group` tinyint(4) NOT NULL default '0',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `share_rate` int(10) unsigned NOT NULL default '0',
  `crash_village` int(11) NOT NULL default '0',
  `crash_dungeon` int(11) NOT NULL default '0',
  `crash_challenge` int(11) NOT NULL default '0',
  `crash_wararea` int(11) NOT NULL default '0',
  `crash_fight_village` int(11) NOT NULL default '0',
  `crash_dead_tower` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`server_group`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `dead_tower_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dead_tower_lag_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime default NULL,
  `server_group` tinyint(4) NOT NULL default '0',
  `min_fps` smallint(6) NOT NULL default '0',
  `avg_fps` smallint(6) NOT NULL default '0',
  `max_fps` smallint(6) NOT NULL default '0',
  `win_fps` smallint(6) NOT NULL default '0',
  `full_fps` smallint(6) NOT NULL default '0',
  `full_win_fps` smallint(6) default '0',
  `full_win_nosync_fps` smallint(6) NOT NULL default '0',
  `frame1` int(11) NOT NULL default '0',
  `time1` float(7,3) NOT NULL default '0.000',
  `frame2` int(11) NOT NULL default '0',
  `time2` float(7,3) NOT NULL default '0.000',
  `frame3` int(11) NOT NULL default '0',
  `time3` float(7,3) NOT NULL default '0.000',
  `frame4` int(11) NOT NULL default '0',
  `time4` float(7,3) NOT NULL default '0.000',
  `frame5` int(11) NOT NULL default '0',
  `time5` float(7,3) NOT NULL default '0.000',
  `frame6` int(11) NOT NULL default '0',
  `time6` float(7,3) NOT NULL default '0.000',
  `share_rate` int(10) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `dead_tower_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dead_tower_lag_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `win_fps` int(10) unsigned NOT NULL default '0',
  `win_fps_cnt` int(11) NOT NULL default '0',
  `full_fps` int(10) unsigned NOT NULL default '0',
  `full_fps_cnt` int(11) NOT NULL default '0',
  `full_win_fps` int(10) unsigned NOT NULL default '0',
  `full_win_fps_cnt` int(11) NOT NULL default '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL default '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `deathtower_ting_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deathtower_ting_log` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `ting_cnt` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `deathtower_ting_log_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deathtower_ting_log_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `ting_cnt` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `directx_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `directx_version` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL default '0',
  `ver_etc` int(10) unsigned NOT NULL default '0',
  `ver_8_x` int(10) unsigned NOT NULL default '0',
  `ver_9_0` int(10) unsigned NOT NULL default '0',
  `ver_9_0_a` int(10) unsigned NOT NULL default '0',
  `ver_9_0_b` int(10) unsigned NOT NULL default '0',
  `ver_9_0_c` int(10) unsigned NOT NULL default '0',
  `ver_10_x` int(10) unsigned NOT NULL default '0',
  `ver_11_x` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`server_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `dungeon_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dungeon_lag_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime default NULL,
  `server_group` tinyint(4) NOT NULL default '0',
  `min_fps` smallint(6) NOT NULL default '0',
  `avg_fps` smallint(6) NOT NULL default '0',
  `max_fps` smallint(6) NOT NULL default '0',
  `win_fps` smallint(6) NOT NULL default '0',
  `full_fps` smallint(6) NOT NULL default '0',
  `full_win_fps` smallint(6) default '0',
  `full_win_nosync_fps` smallint(6) NOT NULL default '0',
  `frame1` int(11) NOT NULL default '0',
  `time1` float(7,3) NOT NULL default '0.000',
  `frame2` int(11) NOT NULL default '0',
  `time2` float(7,3) NOT NULL default '0.000',
  `frame3` int(11) NOT NULL default '0',
  `time3` float(7,3) NOT NULL default '0.000',
  `frame4` int(11) NOT NULL default '0',
  `time4` float(7,3) NOT NULL default '0.000',
  `frame5` int(11) NOT NULL default '0',
  `time5` float(7,3) NOT NULL default '0.000',
  `frame6` int(11) NOT NULL default '0',
  `time6` float(7,3) NOT NULL default '0.000',
  `share_rate` int(10) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `dungeon_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dungeon_lag_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `win_fps` int(10) unsigned NOT NULL default '0',
  `win_fps_cnt` int(11) NOT NULL default '0',
  `full_fps` int(10) unsigned NOT NULL default '0',
  `full_fps_cnt` int(11) NOT NULL default '0',
  `full_win_fps` int(10) unsigned NOT NULL default '0',
  `full_win_fps_cnt` int(11) NOT NULL default '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL default '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `fight_village_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fight_village_lag_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime default NULL,
  `server_group` tinyint(4) NOT NULL default '0',
  `min_fps` smallint(6) NOT NULL default '0',
  `avg_fps` smallint(6) NOT NULL default '0',
  `max_fps` smallint(6) NOT NULL default '0',
  `win_fps` smallint(6) NOT NULL default '0',
  `full_fps` smallint(6) NOT NULL default '0',
  `full_win_fps` smallint(6) default '0',
  `full_win_nosync_fps` smallint(6) NOT NULL default '0',
  `frame1` int(11) NOT NULL default '0',
  `time1` float(7,3) NOT NULL default '0.000',
  `frame2` int(11) NOT NULL default '0',
  `time2` float(7,3) NOT NULL default '0.000',
  `frame3` int(11) NOT NULL default '0',
  `time3` float(7,3) NOT NULL default '0.000',
  `frame4` int(11) NOT NULL default '0',
  `time4` float(7,3) NOT NULL default '0.000',
  `frame5` int(11) NOT NULL default '0',
  `time5` float(7,3) NOT NULL default '0.000',
  `frame6` int(11) NOT NULL default '0',
  `time6` float(7,3) NOT NULL default '0.000',
  `share_rate` int(10) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `fight_village_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fight_village_lag_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `win_fps` int(10) unsigned NOT NULL default '0',
  `win_fps_cnt` int(11) NOT NULL default '0',
  `full_fps` int(10) unsigned NOT NULL default '0',
  `full_fps_cnt` int(11) NOT NULL default '0',
  `full_win_fps` int(10) unsigned NOT NULL default '0',
  `full_win_fps_cnt` int(11) NOT NULL default '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL default '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `lag_stat_dungeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lag_stat_dungeon` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL default '0',
  `dungeon_idx` int(11) NOT NULL default '0',
  `first_average` int(10) unsigned NOT NULL default '0',
  `first_deviation` int(10) unsigned NOT NULL default '0',
  `first_count` int(11) NOT NULL default '0',
  `boss_average` int(10) unsigned NOT NULL default '0',
  `boss_deviation` int(10) unsigned NOT NULL default '0',
  `boss_count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`server_id`,`dungeon_idx`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `lag_stat_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lag_stat_module` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_id` tinyint(4) NOT NULL default '0',
  `module` tinyint(4) NOT NULL default '0',
  `average` int(10) unsigned NOT NULL default '0',
  `deviation` int(10) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`server_id`,`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `loading_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loading_time` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `load_sec` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`server_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `log_launcher_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_launcher_stat` (
  `occ_date` date NOT NULL default '0000-00-00',
  `execute` int(11) NOT NULL default '0',
  `cancel` int(11) NOT NULL default '0',
  `success` int(11) NOT NULL default '0',
  `first_success` int(11) NOT NULL default '0',
  `p2p` double NOT NULL default '0',
  `all_time` bigint(20) NOT NULL default '0',
  `p2p_count` int(11) NOT NULL default '0',
  `all_time_count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `monitoring_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitoring_spec` (
  `unique_id` int(10) unsigned NOT NULL auto_increment,
  `modify_time` datetime default NULL,
  `spec_id` int(10) unsigned default NULL,
  `cpu_vendor` tinyint(4) NOT NULL default '0',
  `cpu_processor_num` tinyint(4) NOT NULL default '0',
  `above_cpu_clock` int(11) NOT NULL default '0',
  `below_cpu_clock` int(11) NOT NULL default '0',
  `ram` smallint(6) NOT NULL default '0',
  `videocard_vendor` int(11) NOT NULL default '0',
  `videocard_device` int(11) NOT NULL default '0',
  `videocard_texture_mem` smallint(6) NOT NULL default '0',
  `os_version` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`unique_id`),
  KEY `idx1` USING BTREE (`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `p2p_connect_success_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2p_connect_success_rate` (
  `no` int(10) unsigned NOT NULL auto_increment,
  `server_group` tinyint(3) unsigned NOT NULL,
  `connected_type` tinyint(4) NOT NULL,
  `required_time` int(10) unsigned NOT NULL,
  `check_time` int(10) unsigned NOT NULL default '0',
  `nation_code` varchar(15) NOT NULL,
  `peer_address` varchar(15) NOT NULL,
  `occ_date` datetime NOT NULL,
  PRIMARY KEY  (`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='대만 P2P 홀펀칭 성공&실패 여결 타입과 IP까지 함께남기는 작업';
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `p2p_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2p_statistics` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL default '0',
  `p2p_user` int(10) unsigned default '0',
  `p2p_min_ping` int(10) unsigned default '0',
  `p2p_max_ping` int(10) unsigned default '0',
  `p2p_avg_ping` int(10) unsigned default '0',
  `p2p_over_ping_100` int(10) unsigned default '0',
  `p2p_over_ping_200` int(10) unsigned default '0',
  `p2p_over_ping_300` int(10) unsigned default '0',
  `p2p_over_ping_400` int(10) unsigned default '0',
  `relay_user` int(10) unsigned default '0',
  `relay_min_ping` int(10) unsigned default '0',
  `relay_max_ping` int(10) unsigned default '0',
  `relay_avg_ping` int(10) unsigned default '0',
  `relay_over_ping_100` int(10) unsigned default '0',
  `relay_over_ping_200` int(10) unsigned default '0',
  `relay_over_ping_300` int(10) unsigned default '0',
  `relay_over_ping_400` int(10) unsigned default '0',
  PRIMARY KEY  (`occ_time`,`server_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `p2pnetwork_statistic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2pnetwork_statistic` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_group` tinyint(4) NOT NULL default '0',
  `success_party_try` int(11) NOT NULL default '0',
  `total_party_try` int(11) NOT NULL default '0',
  `dungeon_bad_ping` int(11) NOT NULL default '0',
  `dungeon_total` int(11) NOT NULL default '0',
  `pvp_bad_ping` int(11) NOT NULL default '0',
  `pvp_total` int(11) NOT NULL default '0',
  `success_dungeon_clear` int(11) NOT NULL default '0',
  `total_dungeon_clear` int(11) NOT NULL default '0',
  `fair_pvp_total` int(11) default NULL,
  `fair_pvp_bad_ping` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `idx1` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `p2pnetwork_statistic_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p2pnetwork_statistic_daily` (
  `cur_date` date NOT NULL default '0000-00-00',
  `success_party` float(3,2) NOT NULL default '0.00',
  `dungeon_bad` float(3,2) NOT NULL default '0.00',
  `pvp_bad` float(3,2) NOT NULL default '0.00',
  `success_dungeon_clear` float(3,2) NOT NULL default '0.00',
  `fair_pvp_bad` float(3,2) NOT NULL default '0.00',
  PRIMARY KEY  (`cur_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `packet_overflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packet_overflow` (
  `packet_type` smallint(5) unsigned NOT NULL default '0',
  `packet_kind` varchar(255) NOT NULL default '',
  `cnt` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`packet_type`,`packet_kind`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `powerwar_lag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerwar_lag` (
  `m_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `round` smallint(5) unsigned NOT NULL default '0',
  `player` tinyint(3) unsigned NOT NULL default '0',
  `lag_avg` float unsigned NOT NULL default '0',
  `lag_cnt` float unsigned NOT NULL default '0',
  PRIMARY KEY  (`m_id`,`occ_time`,`round`),
  KEY `round_idx` USING BTREE (`occ_time`,`round`),
  KEY `player_idx` USING BTREE (`occ_time`,`player`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `powerwar_loading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerwar_loading` (
  `m_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `round` smallint(5) unsigned NOT NULL default '0',
  `player` tinyint(3) unsigned NOT NULL default '0',
  `my_loading` smallint(5) unsigned NOT NULL default '0',
  `other_loading` smallint(5) unsigned NOT NULL default '0',
  `vs_loading` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`m_id`,`occ_time`,`round`),
  KEY `round_idx` USING BTREE (`occ_time`,`round`),
  KEY `player_idx` USING BTREE (`occ_time`,`player`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `powerwar_ting_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `powerwar_ting_type` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `server_id` tinyint(3) unsigned NOT NULL default '0',
  `ting_type` tinyint(3) unsigned NOT NULL default '0',
  `ting_cnt` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`server_id`,`ting_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `spec_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spec_info` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `vendor_id` int(10) unsigned NOT NULL default '0',
  `device_id` int(10) unsigned NOT NULL default '0',
  `vendor_name` varchar(50) NOT NULL default '',
  `device_name` varchar(120) NOT NULL default '',
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `technical_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technical_category` (
  `cateno` int(11) unsigned NOT NULL default '0',
  `pcateno` int(11) unsigned NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `step` int(11) NOT NULL default '0',
  KEY `idx1` USING BTREE (`cateno`,`pcateno`),
  KEY `idx2` USING BTREE (`pcateno`,`cateno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `ting_user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ting_user_account` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `m_id` int(10) unsigned NOT NULL default '0',
  `minute` tinyint(3) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `ting_user_spec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ting_user_spec` (
  `m_id` int(10) unsigned NOT NULL default '0',
  `reg_datetime` datetime NOT NULL default '0000-00-00 00:00:00',
  `cpu_vendor` char(1) NOT NULL default '0',
  `cpu_num` char(1) NOT NULL default '0',
  `cpu_clock` int(10) unsigned NOT NULL default '0',
  `ram` smallint(5) unsigned NOT NULL default '0',
  `video_vendor` smallint(5) unsigned NOT NULL default '0',
  `video_device` smallint(5) unsigned NOT NULL default '0',
  `video_ram` smallint(5) unsigned NOT NULL default '0',
  `os` char(1) NOT NULL default '0',
  `os_bit` char(1) NOT NULL default '0',
  PRIMARY KEY  (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `used_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `used_memory` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `minute_type` char(1) NOT NULL default '0',
  `module` char(1) NOT NULL default '0',
  `memory` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`minute_type`,`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `user_ting_timecheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ting_timecheck` (
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `minute` int(11) NOT NULL default '0',
  `cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_time`,`minute`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `village_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_lag_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime default NULL,
  `server_group` tinyint(4) NOT NULL default '0',
  `min_fps` smallint(6) NOT NULL default '0',
  `avg_fps` smallint(6) NOT NULL default '0',
  `max_fps` smallint(6) NOT NULL default '0',
  `win_fps` smallint(6) NOT NULL default '0',
  `full_fps` smallint(6) NOT NULL default '0',
  `full_win_fps` smallint(6) default '0',
  `full_win_nosync_fps` smallint(6) NOT NULL default '0',
  `frame1` int(11) NOT NULL default '0',
  `time1` float(7,3) NOT NULL default '0.000',
  `frame2` int(11) NOT NULL default '0',
  `time2` float(7,3) NOT NULL default '0.000',
  `frame3` int(11) NOT NULL default '0',
  `time3` float(7,3) NOT NULL default '0.000',
  `frame4` int(11) NOT NULL default '0',
  `time4` float(7,3) NOT NULL default '0.000',
  `frame5` int(11) NOT NULL default '0',
  `time5` float(7,3) NOT NULL default '0.000',
  `frame6` int(11) NOT NULL default '0',
  `time6` float(7,3) NOT NULL default '0.000',
  `share_rate` int(10) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `village_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_lag_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `win_fps` int(10) unsigned NOT NULL default '0',
  `win_fps_cnt` int(11) NOT NULL default '0',
  `full_fps` int(10) unsigned NOT NULL default '0',
  `full_fps_cnt` int(11) NOT NULL default '0',
  `full_win_fps` int(10) unsigned NOT NULL default '0',
  `full_win_fps_cnt` int(11) NOT NULL default '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL default '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `wararea_lag_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wararea_lag_index` (
  `spec_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime default NULL,
  `server_group` tinyint(4) NOT NULL default '0',
  `min_fps` smallint(6) NOT NULL default '0',
  `avg_fps` smallint(6) NOT NULL default '0',
  `max_fps` smallint(6) NOT NULL default '0',
  `win_fps` smallint(6) NOT NULL default '0',
  `full_fps` smallint(6) NOT NULL default '0',
  `full_win_fps` smallint(6) default '0',
  `full_win_nosync_fps` smallint(6) NOT NULL default '0',
  `frame1` int(11) NOT NULL default '0',
  `time1` float(7,3) NOT NULL default '0.000',
  `frame2` int(11) NOT NULL default '0',
  `time2` float(7,3) NOT NULL default '0.000',
  `frame3` int(11) NOT NULL default '0',
  `time3` float(7,3) NOT NULL default '0.000',
  `frame4` int(11) NOT NULL default '0',
  `time4` float(7,3) NOT NULL default '0.000',
  `frame5` int(11) NOT NULL default '0',
  `time5` float(7,3) NOT NULL default '0.000',
  `frame6` int(11) NOT NULL default '0',
  `time6` float(7,3) NOT NULL default '0.000',
  `share_rate` int(10) unsigned NOT NULL default '0',
  KEY `idx1` USING BTREE (`spec_id`,`occ_time`,`server_group`),
  KEY `idx2` USING BTREE (`occ_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `wararea_lag_index_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wararea_lag_index_daily` (
  `occ_date` date NOT NULL default '0000-00-00',
  `spec_id` int(10) unsigned NOT NULL default '0',
  `win_fps` int(10) unsigned NOT NULL default '0',
  `win_fps_cnt` int(11) NOT NULL default '0',
  `full_fps` int(10) unsigned NOT NULL default '0',
  `full_fps_cnt` int(11) NOT NULL default '0',
  `full_win_fps` int(10) unsigned NOT NULL default '0',
  `full_win_fps_cnt` int(11) NOT NULL default '0',
  `full_win_nosync_fps` int(10) unsigned NOT NULL default '0',
  `full_win_nosync_fps_cnt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`spec_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

