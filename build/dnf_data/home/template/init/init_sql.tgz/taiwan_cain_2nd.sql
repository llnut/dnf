
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `charac_advance_altar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_advance_altar` (
  `charac_no` int(11) NOT NULL default '0' COMMENT 'ﾄｳｸｯﾅﾍｹ?｣',
  `ridable_id` int(11) NOT NULL default '0' COMMENT 'ｺｯｽﾅｸ?ｺﾅﾍ ｾﾆﾀﾌｵ',
  `ticket_free` smallint(6) NOT NULL default '0' COMMENT 'ｹｫｷ眤ﾔﾀ螻ﾇ(ｻ鄂ﾅﾀﾇ ﾃﾊｴ??ﾃｳｷｳ ｸﾅﾀﾏ ﾃ､ｿ??',
  `ticket_cera` smallint(6) NOT NULL default '0' COMMENT 'ｼｼｶ?･ｿ｡ｼｭ ｱｸｸﾅﾇﾑ ﾀｯｷ眤ﾔﾀ螻ﾇ',
  `star_game` int(11) NOT NULL default '0' COMMENT 'ｽｺﾅﾗﾀﾌﾁ?ﾅｬｸｮｾ?ｺｸｻ?ｸｷﾎ ｹﾞﾀｺ star (ﾁ?｡ﾇﾏｰ?ｰｨｼﾒ ｾ?ｽ)',
  `star_cera` int(11) NOT NULL default '0' COMMENT 'ｼｼｶ?･ｿ｡ｼｭ ｱｸｸﾅﾇﾑ ﾀｯｷ?star(ﾁ?｡ﾇﾏｰ?ｰｨｼﾒ ｾ?ｽ)',
  `star_usable` int(11) NOT NULL default '0' COMMENT 'ｻ鄙?｡ｴﾉﾇﾑ star (=ｻ鄙?ﾏｰ?ｳｲﾀｺ star)',
  `survival_best` smallint(6) NOT NULL default '0' COMMENT 'ｼｭｹﾙﾀﾌｹ??蠢｡ｼｭ ﾅｬｸｮｾ?ﾑ ﾃﾖｴ?ｽｺﾅﾗﾀﾌﾁ??｣',
  `star_reset_count` smallint(6) NOT NULL default '0' COMMENT 'starｸｦ ﾃﾊｱ篳ｭﾇﾑ ﾈｸｼ?ｱ篳ｹ:ﾃﾊｱ篳ｭ ﾈｽｼ?｡ ｵ??ｺ??ﾌ ｴﾙｸｧ)',
  `is_unlock_stage_effect` smallint(6) NOT NULL default '0' COMMENT 'ｽｺﾅﾗﾀﾌﾁ?unlock ﾀﾌﾆ衄ｮｸｦ ｺｸｿｩﾁ狎ﾟ ﾇﾏｴﾂﾁ?',
  `stage_list` blob NOT NULL COMMENT 'ﾅｬｸｮｾ?ﾑ, ﾀﾔﾀ?ﾇﾒ ｼ?ﾀﾖｴﾂ ｽｺﾅﾗﾀﾌﾁ?ｮｽｺﾆｮ',
  `slot_list` blob NOT NULL COMMENT 'ｽｽｷﾔ ｸｮｽｺﾆｮ',
  `buy_item_list` blob NOT NULL COMMENT 'ｾ?ﾗｷｹﾀﾌｵ?ｻ?｡ｿ｡ｼｭ ｱｸｸﾅﾇﾑ ｾﾆﾀﾌﾅﾛ ｸｮｽｺﾆｮ',
  `reward_list` blob NOT NULL COMMENT 'ｾ??ｺｸｻ?ｸｮｽｺﾆｮ',
  PRIMARY KEY  (`charac_no`,`ridable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `charac_advance_altar_item_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_advance_altar_item_desc` (
  `ridable_id` int(11) NOT NULL default '0' COMMENT 'ｺｯｽﾅｸ?ｺﾅﾍ ｾﾆﾀﾌｵ',
  `item_type` smallint(6) NOT NULL default '0' COMMENT 'ｾﾆﾀﾌﾅﾛﾅｸﾀﾔ 0:ﾀｯｴﾖ, 1:ｽｺﾅｳ, 2:ﾅｸｿ',
  `item_id` int(11) NOT NULL default '0' COMMENT 'ｾﾆﾀﾌﾅﾛｾﾆﾀﾌｵ',
  `item_desc` blob NOT NULL COMMENT 'ｾﾆﾀﾌﾅﾛｼｳｸ',
  PRIMARY KEY  (`ridable_id`,`item_type`,`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `charac_advance_altar_item_desc` VALUES (1,0,1000,''),(1,0,2000,''),(1,0,3000,''),(1,0,4000,''),(1,0,5000,''),(1,0,6000,''),(1,0,7000,''),(1,0,8000,''),(1,1,100,''),(1,1,1001,''),(1,1,1501,''),(1,1,2001,''),(1,1,3001,''),(1,1,4001,''),(1,1,5001,''),(1,2,12610,''),(1,2,12617,''),(1,2,64597,''),(1,2,64632,'');
DROP TABLE IF EXISTS `charac_black_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_black_info` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `black_point` smallint(5) unsigned NOT NULL default '0',
  `offset_point` smallint(5) unsigned NOT NULL default '0',
  `problem_child_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `charac_black_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_black_list` (
  `m_id` int(10) unsigned NOT NULL default '0',
  `charac_no` int(10) unsigned NOT NULL default '0',
  `charac_name` varchar(20) NOT NULL default '',
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`m_id`,`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `charac_event_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_event_items` (
  `id` int(11) NOT NULL auto_increment,
  `charac_no` int(11) NOT NULL default '0',
  `it_id` int(11) NOT NULL default '0',
  `event_code` int(11) NOT NULL default '0',
  `reg_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `delete_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `delete_flag` tinyint(4) NOT NULL default '0',
  `stack_count` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx1` USING BTREE (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `charac_inven_expand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_inven_expand` (
  `charac_no` int(11) NOT NULL default '0',
  `cargo` blob NOT NULL,
  `cargo_capacity` int(10) unsigned NOT NULL default '0',
  `jewel` blob NOT NULL,
  `current_equipslot` char(1) NOT NULL default '',
  `switch_equipslot` blob NOT NULL,
  `expand_equipslot` blob NOT NULL,
  `redeem_info` blob NOT NULL,
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `charac_item_lock_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charac_item_lock_info` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `item_lock_info` blob,
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `combo_skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `combo_skill` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `combo_idx` int(10) unsigned NOT NULL default '0',
  `value1` smallint(5) unsigned NOT NULL default '0',
  `value2` smallint(5) unsigned NOT NULL default '0',
  `value3` smallint(5) unsigned NOT NULL default '0',
  `value4` smallint(5) unsigned NOT NULL default '0',
  `value5` smallint(5) unsigned NOT NULL default '0',
  `value6` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`charac_no`,`combo_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `combo_skill_2nd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `combo_skill_2nd` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `combo_idx` int(10) unsigned NOT NULL default '0',
  `value1` smallint(5) unsigned NOT NULL default '0',
  `value2` smallint(5) unsigned NOT NULL default '0',
  `value3` smallint(5) unsigned NOT NULL default '0',
  `value4` smallint(5) unsigned NOT NULL default '0',
  `value5` smallint(5) unsigned NOT NULL default '0',
  `value6` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`charac_no`,`combo_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `creature_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creature_items` (
  `ui_id` int(11) NOT NULL auto_increment,
  `charac_no` int(11) NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `it_id` int(10) unsigned NOT NULL default '0',
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `name` varchar(12) NOT NULL default '',
  `stomach` int(10) unsigned NOT NULL default '0',
  `exp` int(10) unsigned NOT NULL default '0',
  `endurance` tinyint(3) unsigned NOT NULL default '0',
  `creature_type` tinyint(4) NOT NULL default '0',
  `no_charge` tinyint(4) NOT NULL default '0',
  `stat` tinyint(4) NOT NULL default '0',
  `item_lock_key` tinyint(3) unsigned NOT NULL default '0',
  `ipg_agency_no` varchar(32) NOT NULL default '',
  `expire_date` datetime NOT NULL default '9999-12-31 23:59:59',
  `delete_date` datetime NOT NULL default '9999-12-31 23:59:59',
  PRIMARY KEY  (`ui_id`),
  KEY `idx_charac_no` USING BTREE (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `creature_items_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creature_items_del` (
  `sdate` date NOT NULL default '0000-00-00',
  `ui_id` int(11) NOT NULL default '0',
  `charac_no` int(11) NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `it_id` int(10) unsigned NOT NULL default '0',
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `name` varchar(12) NOT NULL default '',
  `stomach` int(10) unsigned NOT NULL default '0',
  `exp` int(10) unsigned NOT NULL default '0',
  `endurance` tinyint(3) unsigned NOT NULL default '0',
  `creature_type` tinyint(4) NOT NULL default '0',
  `no_charge` tinyint(4) NOT NULL default '0',
  `stat` tinyint(4) NOT NULL default '0',
  `item_lock_key` tinyint(4) NOT NULL default '0',
  `ipg_agency_no` varchar(32) NOT NULL default '',
  `expire_date` datetime NOT NULL default '9999-12-31 23:59:59',
  `delete_date` datetime NOT NULL default '9999-12-31 23:59:59',
  PRIMARY KEY  (`sdate`,`ui_id`),
  KEY `idx_charac_no_exp_dele_date` USING BTREE (`charac_no`,`expire_date`,`delete_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `dblab_avatar_socket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dblab_avatar_socket` (
  `it_id` int(11) NOT NULL default '0',
  `jewel_socket` varchar(600) default NULL,
  PRIMARY KEY  (`it_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `fair_pvp_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fair_pvp_score` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `private_win` int(10) unsigned NOT NULL default '0',
  `private_lose` int(10) unsigned NOT NULL default '0',
  `private_draw` int(10) unsigned NOT NULL default '0',
  `relay_battle_win` int(10) unsigned NOT NULL default '0',
  `relay_battle_lose` int(10) unsigned NOT NULL default '0',
  `relay_battle_draw` int(10) unsigned NOT NULL default '0',
  `relay_battle_2kill` int(10) unsigned NOT NULL default '0',
  `successive_win` int(10) unsigned NOT NULL default '0',
  `job_score` blob,
  `relay_battle_3kill` int(10) unsigned default '0',
  `max_successive_win` int(10) unsigned default '0',
  `daily_play_count` int(10) unsigned NOT NULL default '0',
  `last_play_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `pvp_mission_info` blob,
  `give_item` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `charac_no` int(11) NOT NULL default '0',
  `money` int(11) unsigned NOT NULL default '0',
  `coin` int(11) unsigned NOT NULL default '0',
  `inventory` blob NOT NULL,
  `equipslot` blob NOT NULL,
  `pay_coin` int(11) unsigned NOT NULL default '0',
  `event_coin` int(11) unsigned NOT NULL default '0',
  `creature` blob NOT NULL,
  `creature_flag` tinyint(4) NOT NULL default '0',
  `katagaki` blob NOT NULL,
  `inventory_capacity` int(10) unsigned NOT NULL default '0',
  `avatar_coin` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `letter` (
  `letter_id` int(11) NOT NULL auto_increment,
  `charac_no` int(11) NOT NULL default '0',
  `send_charac_no` int(11) NOT NULL default '0',
  `send_charac_name` varchar(20) NOT NULL default '',
  `letter_text` varchar(255) NOT NULL default '',
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `stat` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`letter_id`),
  KEY `idx_charac_no` USING BTREE (`charac_no`),
  KEY `idx_reg_date` USING BTREE (`reg_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `letter_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `letter_del` (
  `sdate` date NOT NULL default '0000-00-00',
  `letter_id` int(11) unsigned NOT NULL default '0',
  `charac_no` int(11) NOT NULL default '0',
  `send_charac_no` int(11) NOT NULL default '0',
  `send_charac_name` varchar(20) NOT NULL default '',
  `letter_text` varchar(255) NOT NULL default '',
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `stat` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`sdate`,`letter_id`),
  KEY `idx_charac_no` USING BTREE (`charac_no`),
  KEY `idx_reg_date` USING BTREE (`reg_date`),
  KEY `idx_letter_del_id` USING BTREE (`letter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `member_avatar_coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_avatar_coin` (
  `m_id` int(11) NOT NULL default '0',
  `avatar_coin` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `postal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postal` (
  `postal_id` int(10) unsigned NOT NULL auto_increment,
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `send_charac_no` int(11) NOT NULL default '0',
  `send_charac_name` varchar(20) NOT NULL default '',
  `receive_charac_no` int(11) NOT NULL default '0',
  `item_id` int(10) unsigned NOT NULL default '0',
  `add_info` int(11) NOT NULL default '0',
  `endurance` smallint(5) unsigned NOT NULL default '0',
  `upgrade` tinyint(3) unsigned NOT NULL default '0',
  `amplify_option` tinyint(3) unsigned NOT NULL default '0',
  `amplify_value` mediumint(8) unsigned NOT NULL default '0',
  `gold` int(10) unsigned NOT NULL default '0',
  `receive_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `delete_flag` tinyint(3) unsigned NOT NULL default '0',
  `avata_flag` tinyint(4) NOT NULL default '0',
  `unlimit_flag` tinyint(4) NOT NULL default '0',
  `seal_flag` tinyint(4) NOT NULL default '0',
  `creature_flag` tinyint(4) NOT NULL default '0',
  `postal` int(11) NOT NULL default '0',
  `letter_id` int(11) NOT NULL default '0',
  `extend_info` int(11) NOT NULL default '0',
  `ipg_db_id` tinyint(4) NOT NULL default '0',
  `ipg_transaction_id` int(11) NOT NULL default '0',
  `ipg_nexon_id` varchar(32) NOT NULL default '',
  `auction_id` bigint(20) unsigned NOT NULL default '0',
  `random_option` varbinary(14) NOT NULL default '',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `item_guid` varbinary(10) NOT NULL default '',
  PRIMARY KEY  (`postal_id`),
  KEY `idx_send_charac_no` USING BTREE (`send_charac_no`),
  KEY `idx_receive_charac_no` USING BTREE (`receive_charac_no`),
  KEY `idx_occ_time` USING BTREE (`occ_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `postal_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postal_del` (
  `sdate` date NOT NULL default '0000-00-00',
  `postal_id` int(10) unsigned NOT NULL default '0',
  `occ_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `send_charac_no` int(11) NOT NULL default '0',
  `send_charac_name` varchar(20) NOT NULL default '',
  `receive_charac_no` int(11) NOT NULL default '0',
  `item_id` int(10) unsigned NOT NULL default '0',
  `add_info` int(11) NOT NULL default '0',
  `endurance` smallint(5) unsigned NOT NULL default '0',
  `upgrade` tinyint(3) unsigned NOT NULL default '0',
  `amplify_option` tinyint(3) unsigned NOT NULL default '0',
  `amplify_value` mediumint(8) unsigned NOT NULL default '0',
  `gold` int(10) unsigned NOT NULL default '0',
  `receive_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `delete_flag` tinyint(3) unsigned NOT NULL default '0',
  `avata_flag` tinyint(4) NOT NULL default '0',
  `unlimit_flag` tinyint(4) NOT NULL default '0',
  `seal_flag` tinyint(4) NOT NULL default '0',
  `creature_flag` tinyint(4) NOT NULL default '0',
  `postal` int(11) NOT NULL default '0',
  `letter_id` int(11) NOT NULL default '0',
  `extend_info` int(11) NOT NULL default '0',
  `ipg_db_id` tinyint(4) NOT NULL default '0',
  `ipg_transaction_id` int(11) NOT NULL default '0',
  `ipg_nexon_id` varchar(32) NOT NULL default '',
  `auction_id` bigint(20) unsigned NOT NULL default '0',
  `random_option` varbinary(14) NOT NULL default '',
  `seperate_upgrade` tinyint(3) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `item_guid` varbinary(10) NOT NULL default '',
  PRIMARY KEY  (`sdate`,`postal_id`),
  KEY `idx_send_charac_no` USING BTREE (`send_charac_no`),
  KEY `idx_receive_charac_no` USING BTREE (`receive_charac_no`),
  KEY `idx_occ_time` USING BTREE (`occ_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill` (
  `charac_no` int(11) NOT NULL default '0',
  `remain_sp` int(11) unsigned NOT NULL default '0',
  `skill_slot` blob NOT NULL,
  `request_sp` blob NOT NULL,
  `sp_garbage` int(11) unsigned NOT NULL default '0',
  `used_sp` int(11) unsigned NOT NULL default '0',
  `remain_sp_2nd` int(11) unsigned NOT NULL default '0',
  `skill_slot_2nd` blob NOT NULL,
  `request_sp_2nd` blob NOT NULL,
  `skill_slot_lethe` blob NOT NULL,
  `lethe_flag` tinyint(4) NOT NULL default '0',
  `skill_slot_lethe_2nd` blob NOT NULL,
  `lethe_flag_2nd` tinyint(4) NOT NULL default '0',
  `remain_sfp_2nd` int(11) unsigned NOT NULL default '0',
  `remain_sfp_1st` int(11) unsigned NOT NULL default '0',
  `skill_command` blob NOT NULL,
  `script_version` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `skill_fair_pvp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_fair_pvp` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `remain_sp` int(10) unsigned NOT NULL default '0',
  `skill_slot` blob,
  `sp_garbage` int(10) unsigned NOT NULL default '0',
  `used_sp` int(10) unsigned NOT NULL default '0',
  `skill_slot_lethe` blob,
  `lethe_flag` tinyint(4) NOT NULL default '0',
  `remain_sp_2nd` int(10) unsigned NOT NULL default '0',
  `skill_slot_2nd` blob,
  `skill_slot_lethe_2nd` blob,
  `lethe_flag_2nd` tinyint(4) NOT NULL default '0',
  `remain_sfp_1st` smallint(5) unsigned NOT NULL default '0',
  `remain_sfp_2nd` smallint(5) unsigned NOT NULL default '0',
  `skill_command` blob,
  `script_version` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `skill_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_index` (
  `no` int(11) NOT NULL auto_increment,
  `job` mediumint(9) NOT NULL default '100',
  `skill_idx` mediumint(9) NOT NULL default '0',
  `skill_name` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`no`),
  KEY `idx_job` USING BTREE (`job`),
  KEY `idx_skill` USING BTREE (`skill_idx`)
) ENGINE=InnoDB AUTO_INCREMENT=1770 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO `skill_index` VALUES (1,0,1,'æ ¼æ“‹'),(2,0,2,'é¬¼å°ç '),(3,0,3,'è‡ªå‹•æ ¼æ“‹'),(4,0,4,'å…‰åŠç²¾é€š'),(5,0,5,'é¬¼æ–¬'),(6,0,6,'å™¬éˆé¬¼æ–¬'),(7,0,7,'é€†è½‰åæ“Š'),(8,0,8,'ä¸‰æ®µæ–¬'),(9,0,9,'æ‹”åˆ€æ–¬'),(10,0,11,'é€£çªåˆº'),(11,0,12,'çŸ­åŠç²¾é€š'),(12,0,13,'å¤ªåˆ€ç²¾é€š'),(13,0,14,'å·¨åŠç²¾é€š'),(14,0,15,'éˆå™¨ç²¾é€š'),(15,0,16,'éŠ€å…‰è½åˆƒ'),(16,0,17,'ç©ºä¸­é€£æ–¬'),(17,0,18,'æ†‘ä¾'),(18,0,19,'è¡€æ°£å–šé†’'),(19,0,20,'åœ°è£‚ Â· æ³¢å‹•åŠ'),(20,0,21,'å†°åˆƒ Â· æ³¢å‹•åŠ'),(21,0,22,'çˆ†ç‚Ž Â· æ³¢å‹•åŠ'),(22,0,23,'å—œè¡€'),(23,0,24,'æ€’æ°£çˆ†ç™¼'),(24,0,25,'é¬¼ç¥ž Â· å¡è´Š'),(25,0,27,'æ­¦å™¨å¥§ç¾©'),(26,0,29,'æš—ä¹‹è¦ªå’Œ'),(27,0,30,'æš—æœˆé™è‡¨'),(28,0,31,'å—œé­‚ä¹‹æ‰‹'),(29,0,32,'æ³¢å‹•çˆ†ç™¼'),(30,0,33,'å…‰åŠæŽŒæ¡'),(31,0,34,'æ­»äº¡æŠ—æ‹’'),(32,0,35,'å°å°è§£é™¤'),(33,0,36,'å†°éœœä¹‹è–©äºž'),(34,0,37,'ç–¾å½±æ‰‹'),(35,0,38,'ç ´æ¥µå…µåˆƒ'),(36,0,39,'æ­¦å™¨ç¯€åˆ¶'),(37,0,40,'æš´èµ°'),(38,0,41,'é¬¼ç¥ž Â· ä¾µè•æ™®æˆ¾è’™'),(39,0,42,'é¬¼é£Ÿ'),(40,0,43,'è‰ä¸Šé£›'),(41,0,44,'æ­»äº¡å¢“ç¢‘'),(42,0,46,'ä¸ŠæŒ‘'),(43,0,47,'æ³¢å‹•åˆ»å°'),(44,0,49,'åŽè·³æ–¬'),(45,0,50,'é‚ªå…‰æ–¬'),(46,0,51,'ä¿®ç¾…é‚ªå…‰æ–¬'),(47,0,52,'æ®ºæ„æ³¢å‹•'),(48,0,53,'æŒ«æŠ˜æ„å¿—'),(49,0,55,'æ®ºæ°£æ„ŸçŸ¥'),(50,0,56,'ç‹‚æˆ°å£«é‡ç”²å°ˆç²¾'),(51,0,57,'é‚ªå…‰æ³¢å‹•é™£'),(52,0,58,'è£‚æ³¢æ–¬'),(53,0,60,'é¬¼å½±é–ƒ'),(54,0,61,'é˜¿ä¿®ç¾…æ¿ç”²å°ˆç²¾'),(55,0,62,'ç„¡é›™æ³¢'),(56,0,63,'è¡€æ°£æ—ºç››'),(57,0,64,'åå­—æ–¬'),(58,0,65,'å´©å±±æ“Š'),(59,0,67,'è£ Â· é¬¼åŠè¡“'),(60,0,68,'ç ´è»å‡é¾æ“Š'),(61,0,72,'çŒ›é¾æ–·ç©ºæ–¬'),(62,0,73,'å¹»å½±åŠèˆž'),(63,0,74,'ä¸å‹•æ˜ŽçŽ‹é™£'),(64,0,75,'é¬¼ç¥ž Â· ç˜Ÿç–«ç¾…ç…ž'),(65,0,76,'è¡€ä¹‹ç‹‚æš´'),(66,0,77,'æœˆå…‰æ–¬'),(67,0,79,'å—œé­‚å°é­”æ–¬'),(68,0,80,'æ»¿æœˆæ–¬'),(69,0,81,'å´©å±±è£‚åœ°æ–¬'),(70,0,82,'é¬¼ç¥ž Â· å†¥ç‚Žå¡æ´›'),(71,0,84,'é¬¼ç¥ž Â· æ®˜å½±å‡±è³ˆ'),(72,0,85,'é­”ç„è¡€å‰Ž'),(73,0,86,'æ¥µ Â· é¬¼åŠè¡“ (æš´é¢¨å¼)'),(74,0,87,'æ€–æ‹‰ä¿®'),(75,0,88,'æ³¢å‹•çœ¼ : çµ‚çµæŠ€'),(76,0,89,'ææ‡¼å…‰ç’°'),(77,0,90,'é®®è¡€ä¹‹æ†¶'),(78,0,91,'æ¥µ Â· é¬¼åŠè¡“ (æ–¬éµå¼)'),(79,0,92,'å¿ƒçœ¼'),(80,0,93,'å™¬é­‚è€…å¸ƒç”²å°ˆç²¾'),(81,0,94,'åŠé­‚è¼•ç”²å°ˆç²¾'),(82,0,95,'å¢“ç¢‘ä¸‰çµ•é™£'),(83,0,96,'é¬¼ç¥ž Â· å†°æ™¶è–©äºž'),(84,0,97,'ç ´ç©ºæ‹”åˆ€æ–¬'),(85,0,98,'ç ´è»æ–¬é¾æ“Š'),(86,0,99,'æ¥µç‚Ž Â· è£‚æ³¢åŠ'),(87,0,100,'æ¥µå†° Â· è£‚æ³¢åŠ'),(88,0,101,'è¡€æ°£çˆ†ç™¼'),(89,0,102,'æ»…é­‚ä¹‹æ‰‹'),(90,0,103,'è¡€æ°£ä¹‹åˆƒ'),(91,0,105,'æµå¿ƒ'),(92,0,107,'æµå¿ƒ : åˆº'),(93,0,108,'æµå¿ƒ : èº'),(94,0,109,'æµå¿ƒ : å‡'),(95,0,110,'æµå¿ƒ : ç‹‚'),(96,0,111,'é¬¼å½±éž­'),(97,0,112,'é¬¼å½±ä¸‰æ“ŠåŠ'),(98,0,115,'å¼·åŒ– - é¬¼åŠéž­'),(99,0,116,'å¼·åŒ– - é¬¼å½±ä¸‰æ“ŠåŠ'),(100,0,139,'å¼·åŒ– - è¡€æ°£å–šé†’'),(101,0,140,'å¼·åŒ– - åœ°è£‚ Â· æ³¢å‹•åŠ'),(102,0,141,'å¼·åŒ– - åå­—æ–¬'),(103,0,142,'å¼·åŒ– - é¬¼æ–¬'),(104,0,143,'å¼·åŒ– - ä¸‰æ®µæ–¬'),(105,0,144,'å¼·åŒ– - é€†è½‰åæ“Š'),(106,0,145,'å¼·åŒ– - è‡ªå‹•æ ¼æ“‹'),(107,0,146,'å¼·åŒ– - é¬¼ç¥ž Â· ä¾µè•æ™®æˆ'),(108,0,147,'å¼·åŒ– - æ†‘ä¾'),(109,0,148,'å¼·åŒ– - æ­»äº¡æŠ—æ‹’'),(110,0,149,'å¼·åŒ– - æš´èµ°'),(111,0,150,'å¼·åŒ– - æ®ºæ„æ³¢å‹•'),(112,0,151,'å¼·åŒ– - æ³¢å‹•åˆ»å°'),(113,0,152,'å¼·åŒ– - çŒ›é¾æ–·ç©ºæ–¬'),(114,0,153,'å¼·åŒ– - éŠ€å…‰è½åˆƒ'),(115,0,154,'å¼·åŒ– - æ‹”åˆ€æ–¬'),(116,0,155,'å¼·åŒ– - æœˆå…‰æ–¬'),(117,0,156,'å¼·åŒ– - é¬¼ç¥ž Â· ç˜Ÿç–«ç¾…ç…'),(118,0,157,'å¼·åŒ– - å´©å±±æ“Š'),(119,0,158,'å¼·åŒ– - å—œé­‚å°é­”æ–¬'),(120,0,159,'å¼·åŒ– - è£‚æ³¢æ–¬'),(121,0,160,'å¼·åŒ– - é¬¼å°ç '),(122,0,161,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(123,0,162,'å¼·åŒ– - é€£çªåˆº'),(124,0,163,'å¼·åŒ– - æ ¼æª”'),(125,0,164,'å¼·åŒ– - é¬¼ç¥ž Â· å¡è´Š'),(126,0,165,'å¼·åŒ– - å—œé­‚ä¹‹æ‰‹'),(127,0,166,'å¼·åŒ– - æ€’æ°£çˆ†ç™¼'),(128,0,167,'å¼·åŒ– - å´©å±±è£‚åœ°æ–¬'),(129,0,168,'å¼·åŒ– - è¡€æ°£ä¹‹åˆƒ'),(130,0,169,'åŽè·³'),(131,0,172,'è¼•ç”²ç²¾é€š'),(132,0,173,'é‡ç”²ç²¾é€š'),(133,0,174,'åŸºç¤Žç²¾é€š'),(134,0,175,'èºç¿”'),(135,0,176,'é å¤è¨˜æ†¶'),(136,0,177,'æŠ•æ“²ç²¾é€š'),(137,0,178,'ç‰©ç†èƒŒæ“Š'),(138,0,179,'ç‰©å“åˆ†è§£'),(139,0,180,'ä¸å±ˆæ„å¿—'),(140,0,181,'ç²¾å·¥'),(141,0,182,'ç´¡ç¹”'),(142,0,183,'æ©Ÿæ¢°'),(143,0,184,'ç…‰é‡‘'),(144,0,185,'çš®ç”²ç²¾é€š'),(145,0,186,'ç‰©ç†æš´æ“Š'),(146,0,187,'å¸ƒç”²ç²¾é€š'),(147,0,188,'é­”æ³•æš´æ“Š'),(148,0,189,'é­”æ³•èƒŒæ“Š'),(149,0,190,'å—èº«è¹²ä¼'),(150,0,191,'é­”æ³•è³¦äºˆ'),(151,0,192,'è£½ä½œå¬å–šäººå¶'),(152,0,193,'éŠé‡‘è¡“'),(153,0,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(154,0,195,'ç”Ÿå‘½ä¹‹æº'),(155,0,196,'æ¿ç”²ç²¾é€š'),(156,0,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(157,0,199,'å¼’ç¥žåŠ : è«¸ç¥žç»ç¥­'),(158,0,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(159,0,201,'æ¥µé€Ÿæˆé•·'),(160,0,210,'å¼·åŒ– - æ³¢å‹•çˆ†ç™¼'),(161,0,211,'å¼·åŒ– - é‚ªå…‰æ–¬'),(162,0,212,'å¼·åŒ– - çˆ†ç‚Žæ³¢å‹•åŠ'),(163,0,213,'å¼·åŒ– - ç„¡é›™æ³¢'),(164,0,214,'å¼·åŒ– - ä¸å‹•æ˜ŽçŽ‹é™£'),(165,0,215,'å¼·åŒ– - ä¸ŠæŒ‘'),(166,0,216,'å¼·åŒ– - å†°åˆƒ Â· æ³¢å‹•åŠ'),(167,0,217,'å¼·åŒ– - å¹»å½±åŠèˆž'),(168,0,218,'å¼·åŒ– - ç ´è»å‡é¾æ“Š'),(169,0,219,'å¼·åŒ– - æµå¿ƒ : åˆº'),(170,0,220,'å¼·åŒ– - æµå¿ƒ : èº'),(171,0,221,'å¼·åŒ– - æµå¿ƒ : å‡'),(172,0,224,'å¼·åŒ– -å†°éœœä¹‹è–©äºž'),(173,0,225,'å¼·åŒ– - æ­»äº¡å¢“ç¢‘'),(174,0,226,'å¼·åŒ– - é¬¼å½±é–ƒ'),(175,0,227,'å¼·åŒ– - é¬¼ç¥ž Â· å†¥ç‚Žé¬¼ç¥'),(176,0,228,'å¼·åŒ– - é¬¼å°ç '),(177,0,231,'é­”ç…žÂ·è¡€éš•'),(178,0,232,'é›·ç¥žé™ä¸– : è£æ±º'),(179,0,234,'å¤©é›· Â· æ³¢å‹•åŠ'),(180,0,235,'æ¥µ Â· ç¥žåŠè¡“ (ç ´ç©ºæ–¬)'),(181,0,236,'æ¥µ Â· ç¥žåŠè¡“ (æµæ˜Ÿè½)'),(182,0,237,'æµ´è¡€ä¹‹æ€’'),(183,0,238,'è¡€é­”Â·å¼’å¤©'),(184,0,242,'çŽ‹è€…è™Ÿä»¤ï¼šå‰æ ¼é™è‡¨'),(185,0,245,'è¬åŠæ­¸å®—'),(186,0,246,'é¬¼æ–¬ï¼šç‹‚æ€’'),(187,0,247,'é¬¼æ–¬ï¼šç…‰ç„'),(188,0,248,'æ¥µ Â· é¦­åŠè¡“ (æ™‚ç©ºæ–¬)'),(189,0,249,'æ¥µ Â· ç¥žåŠè¡“ (çž¬æ–¬)'),(190,0,250,'å¹½é­‚é™è‡¨:å¼'),(191,1,1,'éµå±±é '),(192,1,2,'è¹²ä¼'),(193,1,3,'æ“’æœˆç‚Ž'),(194,1,4,'ç¢Žéª¨'),(195,1,5,'ä¸Šå‹¾æ‹³'),(196,1,6,'ä¸‹æ®µè¸¢'),(197,1,7,'é‹¼ç­‹éµéª¨'),(198,1,8,'åˆ†èº«'),(199,1,9,'èƒŒæ‘”'),(200,1,10,'èƒŒæ‘”å¼·åŒ–'),(201,1,11,'é›·éœ†èƒŒæ‘”'),(202,1,12,'å¿µæ°£æ³¢'),(203,1,13,'æ‹‹æ²™'),(204,1,14,'ä¼è™Žéœ¸çŽ‹æ‹³'),(205,1,15,'ç…å­å¼'),(206,1,16,'èžºæ—‹å¿µæ°£å ´'),(207,1,17,'é·¹è¸'),(208,1,18,'èžºæ—‹å½—æ˜Ÿè½'),(209,1,19,'å¯¸æ‹³'),(210,1,20,'éœ¸é«”è­·ç”²'),(211,1,21,'å¼·åˆ¶ - å¿µæ°£æ³¢'),(212,1,22,'æ‘”æŠ€å¼·åŒ–'),(213,1,24,'èšèƒ½å¿µæ°£ç‚®'),(214,1,25,'å¥‡è¥²å¹»å½±'),(215,1,26,'å¿µå¸æ—‹å¤©ç ´'),(216,1,28,'è–æ­¦é€£ç’°ç ´'),(217,1,29,'å…‰ä¹‹è¦ªå’Œ'),(218,1,30,'å…‰ä¹‹å…µåˆƒ'),(219,1,31,'é¢¨ä¹‹æ°£æ¯'),(220,1,32,'åŠ‡æ¯’æŠµæŠ—'),(221,1,33,'èµ°ç«å…¥é­”'),(222,1,34,'æ‹³å¥—æŽŒæ¡'),(223,1,35,'å¿µæ°£æ„ŸçŸ¥'),(224,1,36,'çƒˆæ—¥å…‰è¼'),(225,1,37,'å¼·æ‹³'),(226,1,38,'å¡—æ¯’'),(227,1,39,'å¼±é»žæ„ŸçŸ¥'),(228,1,40,'å¿µæ°£ç’°ç¹ž'),(229,1,41,'å¿µæ°£åˆ†è§£'),(230,1,42,'å¿µæ°£ç½©'),(231,1,43,'é›™é‡æŠ•æ“²'),(232,1,44,'æŒ‘é‡'),(233,1,45,'çˆªç²¾é€š'),(234,1,46,'å‰è¸¢'),(235,1,47,'è™Žå˜¯ç¥žæ‹³'),(236,1,48,'æ¥µæ­¦éœ¸çš‡æ‹³'),(237,1,49,'æ‹‹æŠ•'),(238,1,50,'æš´åŠ›æŠ“å–'),(239,1,51,'æ»‘è¡ŒæŠ“å–'),(240,1,52,'å¤©ç¾…åœ°ç¶²'),(241,1,54,'é‡Žè »è¡æ’ž'),(242,1,55,'æŠ“è½Ÿç‚®'),(243,1,56,'æ­¦é¬¥è¼•ç”²å°ˆç²¾'),(244,1,57,'æŸ”é“å®¶å®¶è¼•ç”²å°ˆç²¾'),(245,1,58,'æ—‹é¢¨è…¿'),(246,1,60,'ç£šè¥²'),(247,1,62,'ç©ºçµžéŒ˜'),(248,1,63,'æœ«æ—¥é¢¨æš´'),(249,1,64,'æ­»äº¡æ¯’éœ§'),(250,1,65,'çŒ›æ¯’ä¹‹è¡€'),(251,1,66,'æŠ“å–å¥§ç¾©'),(252,1,67,'åƒè“®æ€’æ”¾'),(253,1,68,'é–ƒé›»ä¹‹èˆž'),(254,1,69,'å¹»å½±çˆ†ç¢Ž'),(255,1,70,'æ­¦ç¥žæ­¥'),(256,1,71,'æ­¦ç¥žå¼·è¸¢'),(257,1,72,'äº‚èˆž Â· åƒè‘‰èŠ±'),(258,1,73,'è¡—éœ¸é‡ç”²å°ˆç²¾'),(259,1,74,'ç‹‚ Â· éœ¸çŽ‹æ‹³'),(260,1,75,'æ¯’å½±é‡'),(261,1,76,'æ¯’é›·å¼•çˆ†'),(262,1,77,'è¡—é ­é¢¨æš´'),(263,1,78,'è“„å¿µç‚®'),(264,1,79,'å¿µç¸ : é¾è™Žå˜¯'),(265,1,80,'å´©æ‹³'),(266,1,81,'æŠ˜é ¸'),(267,1,82,'å¹»å½±é€£ç’°è¸¢'),(268,1,83,'æ˜‡é¾æ‹³'),(269,1,84,'ç–¾é¢¨è¿½æ“Š'),(270,1,85,' ç–¾é¢¨é€£æ“Š'),(271,1,86,'é‡‘å‰›ç¢Ž'),(272,1,87,'éœ¹é‚è‚˜æ“Š'),(273,1,88,'è£‚çŸ³ç ´å¤©'),(274,1,89,'åœ°ç„æ–ç±ƒ'),(275,1,90,'å¿µç¸ : é›·é¾å‡ºæµ·'),(276,1,91,'æŸ”åŒ–è‚Œè‚‰'),(277,1,97,'é¬¥æ°£å¸«å¸ƒç”²å°ˆç²¾'),(278,1,98,'ç©¶æ¥µå¿µæ°£ç½©'),(279,1,99,'çŒ›æ¯’æ“’æœˆç‚Ž'),(280,1,100,'ç‹‚ç…æ€’å¼'),(281,1,101,'ç©ºçµžé€£éŒ˜'),(282,1,102,'ç ´ç¢Žæ‹³'),(283,1,103,'å‡é¾éœ¸æ‹³'),(284,1,104,'çˆ†ç¢Žç£šè£‚'),(285,1,105,'æ­»äº¡æ–ç±ƒ'),(286,1,106,'è£‚åœ°é£›æ²™'),(287,1,139,'å¼·åŒ– - æ˜‡é¾æ‹³'),(288,1,140,'å¼·åŒ– - å¿µæ°£æ³¢'),(289,1,141,'å¼·åŒ– - ä¸‹æ®µè¸¢'),(290,1,142,'å¼·åŒ– - èƒŒæ‘”'),(291,1,143,'å¼·åŒ– - è¹²ä¼'),(292,1,144,'å¼·åŒ– - èžºæ—‹å¿µæ°£å ´'),(293,1,145,'å¼·åŒ– - å¿µæ°£ç’°ç¹ž'),(294,1,146,'å¼·åŒ– - éµå±±é '),(295,1,147,'å¼·åŒ– - å¯¸æ‹³'),(296,1,148,'å¼·åŒ– - ç‹‚ Â· éœ¸çŽ‹æ‹³'),(297,1,149,'å¼·åŒ– - å¤©ç¾…åœ°ç¶²'),(298,1,150,'å¼·åŒ– - ç©ºçµžéŒ˜'),(299,1,151,'å¼·åŒ– - èžºæ—‹å½—æ˜Ÿè½'),(300,1,152,'å¼·åŒ– - é‡Žè »è¡æ’ž'),(301,1,153,'å¼·åŒ– - é‹¼ç­‹éµéª¨'),(302,1,154,'å¼·åŒ– - å¿µç¸ : é¾è™Žå˜¯'),(303,1,155,'å¼·åŒ– - ç–¾é¢¨è¿½æ“Š'),(304,1,156,'å¼·åŒ– - é–ƒé›»ä¹‹èˆž'),(305,1,157,'å¼·åŒ– - æ‹‹æ²™'),(306,1,158,'å¼·åŒ– - è¡—é ­é¢¨æš´'),(307,1,159,'å¼·åŒ– - é‡‘å‰›ç¢Ž'),(308,1,160,'å¼·åŒ– - åœ°ç„æ–ç±ƒ'),(309,1,161,'å¼·åŒ– - é›·éœ†èƒŒæ‘”'),(310,1,162,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(311,1,163,'å¼·åŒ– - ä¸Šå‹¾æ‹³'),(312,1,164,'å¼·åŒ– - å‰è¸¢'),(313,1,165,'å¼·åŒ– - åˆ†èº«'),(314,1,166,'å¼·åŒ– - é·¹è¸'),(315,1,167,'å¼·åŒ– - å¿µæ°£ç½©'),(316,1,168,'å¼·åŒ– - å¹»å½±çˆ†ç¢Ž'),(317,1,169,'åŽè·³'),(318,1,172,'è¼•ç”²ç²¾é€š'),(319,1,173,'é‡ç”²ç²¾é€š'),(320,1,174,'åŸºç¤Žç²¾é€š'),(321,1,175,'èºç¿”'),(322,1,176,'é å¤è¨˜æ†¶'),(323,1,177,'æŠ•æ“²ç²¾é€š'),(324,1,178,'ç‰©ç†èƒŒæ“Š'),(325,1,179,'ç‰©å“åˆ†è§£'),(326,1,180,'ä¸å±ˆæ„å¿—'),(327,1,181,'ç²¾å·¥'),(328,1,182,'ç´¡ç¹”'),(329,1,183,'æ©Ÿæ¢°'),(330,1,184,'ç…‰é‡‘'),(331,1,185,'çš®ç”²ç²¾é€š'),(332,1,186,'ç‰©ç†æš´æ“Š'),(333,1,187,'å¸ƒç”²ç²¾é€š'),(334,1,188,'é­”æ³•æš´æ“Š'),(335,1,189,'é­”æ³•èƒŒæ“Š'),(336,1,190,'å—èº«è¹²ä¼'),(337,1,191,'é­”æ³•è³¦äºˆ'),(338,1,192,'è£½ä½œå¬å–šäººå¶'),(339,1,193,'éŠé‡‘è¡“'),(340,1,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(341,1,195,'ç”Ÿå‘½ä¹‹æº'),(342,1,196,'æ¿ç”²ç²¾é€š'),(343,1,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(344,1,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(345,1,201,'æ¥µé€Ÿæˆé•·'),(346,1,210,'å¼·åŒ– - ç…å­å¼'),(347,1,211,'å¼·åŒ– - å¿µç¸ : é›·é¾å‡ºæµ·'),(348,1,212,'å¼·åŒ– - å´©æ‹³'),(349,1,214,'å¼·åŒ– - ç¢Žéª¨'),(350,1,215,'å¼·åŒ– - å¹»å½±é€£ç’°è¸¢'),(351,1,216,'å¼·åŒ– - æ“’æœˆç‚Ž'),(352,1,217,'å¼·åŒ– - æ¯’å½±é‡'),(353,1,218,'å¼·åŒ– - æ¯’é›·å¼•çˆ†'),(354,1,219,'å¼·åŒ– - è£‚åœ°é£›æ²™'),(355,1,220,'å¼·åŒ– - æ‹‹æŠ•'),(356,1,221,'å¼·åŒ– - æŠ˜é ¸'),(357,1,222,'å¼·åŒ– - æ—‹é¢¨è…¿'),(358,1,223,'å¼·åŒ– - éœ¹é‚è‚˜æ“Š '),(359,1,224,'å¼·åŒ– - è£‚çŸ³ç ´å¤©'),(360,1,227,'è’¼å®‡å½—æ˜Ÿè½'),(361,2,1,'çˆ†ç‚Žå½ˆ'),(362,2,2,'å†°å‡å½ˆ'),(363,2,3,'è¿´æ—‹è¸¢'),(364,2,4,'è†æ’ž'),(365,2,5,'çˆ†é ­ä¸€æ“Š'),(366,2,6,'è¸å°„'),(367,2,7,'çž¬è¸¢'),(368,2,8,'èµ·èº«è¿´æ—‹è¸¢'),(369,2,9,'äº‚å°„'),(370,2,10,'é ç¨‹æ ¼æ“‹'),(371,2,11,'å¿«é€Ÿæ‹”æ§'),(372,2,12,'M-137æ ¼æž—æ©Ÿæ§'),(373,2,13,'M-3å™´ç«å™¨'),(374,2,14,'BBQ'),(375,2,15,'ç§»å‹•å°„æ“Š'),(376,2,20,'å›žé ­ä¸€æ“Š'),(377,2,21,'é‡ç«å™¨ç²¾é€š'),(378,2,22,'å·¦è¼ªç²¾é€š'),(379,2,23,'å¿«é€Ÿå¡«è£'),(380,2,26,'å¾©ä»‡åæ“Š'),(381,2,27,'RX-78è¿½æ“Šè€…'),(382,2,28,'Ez-8è‡ªçˆ†è€…'),(383,2,29,'Ex-Sæ¯’è›‡ç‚®'),(384,2,30,'éŠ€å½ˆ'),(385,2,31,'å½ˆè—¥æ”¹è‰¯'),(386,2,32,'ä¸‰é‡æŽ§åˆ¶'),(387,2,33,'ç©ºä¸­å°„æ“Š'),(388,2,34,'é‡ç«å™¨æ‹”æ“Š'),(389,2,35,'æµ®ç©ºæˆªæ“Š'),(390,2,36,'èšç„¦å™´ç«å™¨'),(391,2,37,'æµ®ç©ºéŸ'),(392,2,38,'FM-31æ¦´å½ˆç™¼å°„å™¨'),(393,2,39,'é³å°„ç‚®'),(394,2,40,'åå¦å…‹ç‚®'),(395,2,41,'è“„é›»é³å°„ç‚®'),(396,2,42,'å—œæˆ°è¿½æ“Šè€…'),(397,2,43,'å½è£'),(398,2,44,'é‡ç«å™¨å¥§ç¾©'),(399,2,45,'é‡å­çˆ†å½ˆ'),(400,2,46,'æ©Ÿæ¢°æ”¹è‰¯'),(401,2,47,'æµ®ç©ºå½ˆ'),(402,2,48,'äº¤å‰å°„æ“Š'),(403,2,49,'å½ˆåŒ£æ“´å……'),(404,2,50,'æ©Ÿæ¢°å¼•çˆ†'),(405,2,51,'é›™é·¹è¿´æ—‹'),(406,2,52,'ç ´ç”²å½ˆ'),(407,2,53,'åœ°ç„çƒˆç‚Ž'),(408,2,54,'è¡›æ˜Ÿå…‰æŸ'),(409,2,55,'éŠä¿ çš®ç”²å°ˆç²¾'),(410,2,56,'G-14 æ‰‹é›·'),(411,2,57,'G35L æ„Ÿé›»æ‰‹é›·'),(412,2,58,'G-18C å†°å‡æ‰‹é›·'),(413,2,59,'ç©ºæŠ•æ”¯æ´'),(414,2,60,'æ­»äº¡å·¦è¼ª'),(415,2,61,'é­”å½ˆå°„æ‰‹çš®ç”²å°ˆç²¾'),(416,2,62,'æ½›èƒ½çˆ†ç™¼'),(417,2,63,'ç©ºæˆ°æ©Ÿæ¢° : é¢¨æš´'),(418,2,64,'ç˜‹ç‹‚å± æˆ®'),(419,2,65,'è¡›æ˜Ÿå®šä½'),(420,2,66,'æ­»äº¡å°è¨˜'),(421,2,67,'è“‹æ³¢åŠ ä¹‹æ‹³'),(422,2,68,'é¬¥å¿—ä¹‹æ­Œ'),(423,2,69,'å½ˆè—¥ä¸»å®°'),(424,2,70,'é»‘çŽ«ç‘°ç‰¹ç¨®æˆ°éšŠ'),(425,2,71,'X-1 å£“ç¸®é‡å­ç‚®'),(426,2,72,'å¤šé‡çˆ†é ­'),(427,2,73,'åŠ è¾²ç‚®'),(428,2,74,'å¼·åˆ¶ - åŠ è¾²ç‚®'),(429,2,75,'FM-92 åˆºç ²å½ˆ'),(430,2,76,'é–ƒæ“Šåœ°é›·'),(431,2,77,'C4é ç«¯ç‚¸å½ˆ'),(432,2,78,'å°¼çˆ¾ç‹™æ“Š'),(433,2,79,'G-1æŸ¯æ´›ç´'),(434,2,80,'æ”¹è£ :  G-2 æ—‹é›·'),(435,2,81,'æ”¹è£ : G-3 çŒ›ç¦½'),(436,2,82,'å½ˆè—¥æ”¯æ´'),(437,2,83,'æ””æˆªæ©Ÿå·¥å» '),(438,2,91,'æ©Ÿæ¢°å¸«å¸ƒç”²å°ˆç²¾'),(439,2,92,'é‡ç‚®æ‰‹é‡ç”²å°ˆç²¾'),(440,2,101,'è¿´æ—‹æˆªæ“Š'),(441,2,102,'C4é£›é€Ÿç‚¸å½ˆ'),(442,2,103,'M-61åœ°é›·'),(443,2,104,'æ¥µé™å¤šé‡çˆ†é ­'),(444,2,105,'Ez-10åæ“Šè€…'),(445,2,106,'Ex-S Zeroæ¯’è›‡ç‚®'),(446,2,107,'èšç„¦å¯’å†°å™´å°„å™¨'),(447,2,108,'FM-92 SWåˆºå½ˆç‚®'),(448,2,109,'ç ´è£‚å°„æ“Š'),(449,2,110,'æ­¥æ§ç²¾é€š'),(450,2,130,'ç¬¬ä¸ƒç¿¼å‹•'),(451,2,140,'å¼·åŒ– - çˆ†é ­ä¸€æ“Š'),(452,2,141,'å¼·åŒ– - BBQ'),(453,2,142,'å¼·åŒ– - RX-78è¿½æ“Šè€…'),(454,2,143,'å¼·åŒ– - éŠ€å½ˆ'),(455,2,144,'å¼·åŒ– - é ç¨‹æ ¼æª”'),(456,2,145,'å¼·åŒ– - è¸å°„'),(457,2,146,'å¼·åŒ– - M-3å™´ç«å™¨'),(458,2,147,'å¼·åŒ– - åå¦å…‹ç‚®'),(459,2,148,'å¼·åŒ– - æ©Ÿæ¢°å¼•çˆ†'),(460,2,149,'å¼·åŒ– - G-1æŸ¯æ´›ç´'),(461,2,150,'å¼·åŒ– - äº¤å‰å°„æ“Š'),(462,2,151,'å¼·åŒ– - å½ˆåŒ£æ“´å……'),(463,2,152,'é­”æ”»è½‰æ›'),(464,2,153,'å¼·åŒ– - çž¬è¸¢'),(465,2,154,'å¼·åŒ– - äº‚å°„'),(466,2,155,'å¼·åŒ– - G-14æ‰‹é›·'),(467,2,156,'å¼·åŒ– - åœ°ç„çƒˆç‚Ž'),(468,2,157,'å¼·åŒ– - Ez-8è‡ªçˆ†è€…'),(469,2,158,'å¼·åŒ– - æ””æˆªæ©Ÿå·¥å» '),(470,2,159,'å¼·åŒ– - M-137æ ¼æž—æ©Ÿæ§'),(471,2,160,'å¼·åŒ– - FM-92åˆºå½ˆç‚®'),(472,2,161,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(473,2,162,'å¼·åŒ– - çˆ†ç‚Žå½ˆ'),(474,2,163,'å¼·åŒ– - å†°å‡å½ˆ'),(475,2,164,'å¼·åŒ– - å¾©ä»‡åæ“Š'),(476,2,166,'å¼·åŒ– - è¿´æ—‹è¸¢'),(477,2,167,'å¼·åŒ– - æµ®ç©ºå½ˆ'),(478,2,168,'å¼·åŒ– - è†æ’ž'),(479,2,169,'åŽè·³'),(480,2,172,'è¼•ç”²ç²¾é€š'),(481,2,173,'é‡ç”²ç²¾é€š'),(482,2,174,'åŸºç¤Žç²¾é€š'),(483,2,175,'èºç¿”'),(484,2,176,'é å¤è¨˜æ†¶'),(485,2,177,'æŠ•æ“²ç²¾é€š'),(486,2,178,'ç‰©ç†èƒŒæ“Š'),(487,2,179,'ç‰©å“åˆ†è§£'),(488,2,180,'ä¸å±ˆæ„å¿—'),(489,2,181,'ç²¾å·¥'),(490,2,182,'ç´¡ç¹”'),(491,2,183,'æ©Ÿæ¢°'),(492,2,184,'ç…‰é‡‘'),(493,2,185,'çš®ç”²ç²¾é€š'),(494,2,186,'ç‰©ç†æš´æ“Š'),(495,2,187,'å¸ƒç”²ç²¾é€š'),(496,2,188,'é­”æ³•æš´æ“Š'),(497,2,189,'é­”æ³•èƒŒæ“Š'),(498,2,190,'å—èº«è¹²ä¼'),(499,2,191,'é­”æ³•è³¦äºˆ'),(500,2,192,'è£½ä½œå¬å–šäººå¶'),(501,2,193,'éŠé‡‘è¡“'),(502,2,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(503,2,195,'ç”Ÿå‘½ä¹‹æº'),(504,2,196,'æ¿ç”²ç²¾é€š'),(505,2,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(506,2,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(507,2,201,'æ¥µé€Ÿæˆé•·'),(508,2,211,'å¼·åŒ– - æµ®ç©ºæˆªæ“Š'),(509,2,212,'å¼·åŒ– - ç§»å‹•å°„æ“Š'),(510,2,213,'å¼·åŒ– - é›™é·¹è¿´æ—‹'),(511,2,214,'å¼·åŒ– - å¤šé‡çˆ†é ­'),(512,2,215,'å¼·åŒ– - é³å°„ç‚®'),(513,2,216,'å¼·åŒ– - X-1 å£“ç¸®é‡å­ç‚®'),(514,2,217,'å¼·åŒ– - åŠ è¾²ç‚®'),(515,2,218,'å¼·åŒ– - èšç„¦å™´ç«å™¨'),(516,2,219,'å¼·åŒ– - æ”¹è£ : G-2 æ—‹é›·'),(517,2,220,'å¼·åŒ– - æ”¹è£ : G-3 çŒ›ç¦½'),(518,2,221,'å¼·åŒ– - é‡å­çˆ†å½ˆ'),(519,2,222,'å¼·åŒ– - ç©ºæˆ°æ©Ÿæ¢° : é¢¨æš´'),(520,2,223,'å¼·åŒ– - G35L æ„Ÿé›»æ‰‹é›·'),(521,2,224,'å¼·åŒ– - G18C å†°å‡æ‰‹é›·'),(522,2,225,'å¼·åŒ– - ç ´ç”²å½ˆ'),(523,2,226,'å¼·åŒ– - ç ´è£‚å°„æ“Š'),(524,2,227,'å¼·åŒ– - é–ƒæ“Šåœ°é›·'),(525,2,228,'å¼·åŒ– - C4 é ç«¯ç‚¸å½ˆ'),(526,2,229,'å¼·åŒ– - å°¼çˆ¾ç‹™æ“Š'),(527,2,230,'å¼·åŒ– - Ex-S æ¯’è›‡ç‚®'),(528,2,231,'å¼·åŒ– - ç©ºæŠ•æ”¯æ´'),(529,2,232,'æ¯€æ»…å°„ç·š'),(530,2,233,'è¶…æ–°æ˜Ÿæ ¸çˆ†'),(531,3,1,'é¾èŠ±éœ¸'),(532,3,2,'é­”æ³•ç§€'),(533,3,3,'æ›¿èº«è‰äºº'),(534,3,4,'é¾ç‰™'),(535,3,5,'ç‚«ç´‹ : ç„¡å±¬æ€§'),(536,3,6,'ç‚«ç´‹ : ç«å±¬æ€§'),(537,3,7,'ç‚«ç´‹ : å†°å±¬æ€§'),(538,3,8,'ç‚«ç´‹ : æš—å±¬æ€§'),(539,3,9,'ç‚«ç´‹ : å…‰å±¬æ€§'),(540,3,10,'ç‚«ç´‹å¼·å£“'),(541,3,11,'é­”æ³•æ˜Ÿå½ˆ'),(542,3,12,'å¤©æ“Š'),(543,3,13,'ç¢Žéœ¸'),(544,3,14,'è½èŠ±æŽŒ'),(545,3,15,'å‚‘å…‹çˆ†å½ˆ'),(546,3,16,'å†°éœœé›ªäºº'),(547,3,17,'å…‰é›»é°»'),(548,3,18,'æš—å½±å¤œè²“'),(549,3,19,'é­”æ³•è¨˜æ†¶'),(550,3,20,'éž­æ’»'),(551,3,21,'ç²¾éˆå¬å–š : äºžå¾·ç‚Ž'),(552,3,22,'ç²¾éˆå¬å–š : å†°å¥ˆæ–¯'),(553,3,23,'ç²¾éˆå¬å–š : ç‘Ÿå†¥ç‰¹å…‹'),(554,3,24,'ç²¾éˆå¬å–š : é›·æ²ƒæ–¯'),(555,3,25,'å¥‘ç´„å¬å–š : èµ«å¾·çˆ¾'),(556,3,26,'è™›ç„¡ä¹‹çƒ'),(557,3,27,'å‚‘å…‹é™è‡¨'),(558,3,28,'é©…æ•£é­”æ³•'),(559,3,29,'å…ƒç´ é»žç‡ƒ'),(560,3,30,'å¬å–šç¸è·Ÿéš¨'),(561,3,31,'é›·æ—‹'),(562,3,35,'çŸ›ç²¾é€š'),(563,3,36,'æ£æ£’ç²¾é€š'),(564,3,37,'é­”æ³•è­·ç›¾'),(565,3,38,'ç§»å‹•æ–½æ³•'),(566,3,39,'ç‚«ç´‹ç™¼å°„'),(567,3,40,'è‡ªå‹•ç‚«ç´‹'),(568,3,41,'é å¤é­”æ³•æ›¸'),(569,3,42,'ç©ºä¸­æ–½æ”¾  : å‚‘å…‹çˆ†å½ˆ'),(570,3,43,'æŒ‘é‡äººå¶ : èˆ’éœ²éœ²'),(571,3,44,'å¥‘ç´„å¬å–š  : é»‘é¨Žå£« æ¡‘å'),(572,3,45,'å¥‘ç´„å¬å–š : é­”ç•ŒèŠ±è¥–ç´¢'),(573,3,46,'å¥‘ç´„å¬å–š  : éœ²æ˜“çµ²å¤§å§'),(574,3,47,'ç²¾éˆå¬å–š : ç²¾éˆçŽ‹ä¼Šä¼½'),(575,3,48,'å¬å–šç¸å¼·åŒ–'),(576,3,49,'ç²¾éˆç»ç¥­'),(577,3,50,'é­”åŠ›å°è¨˜'),(578,3,51,'ç»ç¥­æ”»æ“Š : äºžå¾·ç‚Ž'),(579,3,52,'ç»ç¥­æ”»æ“Š : å†°å¥ˆæ–¯'),(580,3,53,'ç»ç¥­æ”»æ“Š : ç‘Ÿå†¥ç‰¹å…‹'),(581,3,54,'ç»ç¥­æ”»æ“Š : é›·æ²ƒæ–¯'),(582,3,55,'å¤©é›·'),(583,3,56,'å†°ç‰†'),(584,3,57,'çƒˆç„°è¡æ“Š'),(585,3,58,'æ¹®æ»…é»‘æ´ž'),(586,3,59,'æ¥µå†°ç››å®´'),(587,3,60,'é­”æ³•è­·ç›¾å¼·åŒ–'),(588,3,61,'ç«ç³»ç²¾é€š'),(589,3,62,'å†°ç³»ç²¾é€š'),(590,3,63,'æš—ç³»ç²¾é€š'),(591,3,64,'å…‰ç³»ç²¾é€š'),(592,3,65,'åœ“èˆžæ£'),(593,3,66,'æµæ˜Ÿé–ƒå½±æ“Š'),(594,3,67,'é­”é¬¥å£«çš®ç”²å°ˆç²¾'),(595,3,68,'å¼·è¥²æµæ˜Ÿæ‰“'),(596,3,69,'ç…Œé¾åƒæœˆåˆ€'),(597,3,70,'ç¬¬å…­å…ƒç´ '),(598,3,73,'å…ƒç´ é›†ä¸­'),(599,3,74,'å±¬æ€§è½Ÿç‚¸'),(600,3,75,'éˆé­‚æ”¯é…'),(601,3,76,'ç²¾éˆå¬å–š : äº¡é­‚é»˜å…‹çˆ¾'),(602,3,77,'ç²¾éˆå¬å–š : æ¥µå…‰æ ¼é›·æž—'),(603,3,78,'ç²¾éˆå¬å–š : å†°å½±é˜¿å¥Žåˆ©'),(604,3,79,'ç²¾éˆå¬å–š : ç«ç„°èµ«ç‘žå…‹'),(605,3,80,'å¥‘ç´„å¬å–š : å¼—åˆ©ç‰¹'),(606,3,81,'å¬å–šç¸ç‹‚åŒ–'),(607,3,82,'å¥‘ç´„å¬å–š : å¾æœè€…å‡±è¥¿'),(608,3,83,'è®Šèº«è²äºžå¨œ'),(609,3,84,'é¬¥ç¥žæ„å¿—'),(610,3,85,'è¦ªå’Œ - æš—å½±å¤œè²“'),(611,3,86,'è¦ªå’Œ - å…‰é›»é°»'),(612,3,87,'è¦ªå’Œ - å†°éœœé›ªäºº'),(613,3,88,'è¦ªå’Œ - å‚‘å…‹çˆ†å½ˆ'),(614,3,89,'å†°å‡ç²‰æœ«'),(615,3,90,'æ­»äº¡ç²‰æœ«'),(616,3,91,'æŽƒæŠŠæŽŒæ¡'),(617,3,92,'æš—å½±æ–—ç¯·'),(618,3,93,'æ”¹é€ èˆ’éœ²éœ²'),(619,3,95,'è®Šç•°è’¼è …æ‹'),(620,3,96,'å‚³èªªå¬å–š : é€†æœˆè€…æ‹‰èŽ«'),(621,3,97,'å¹¸é‹æ£’æ£’ç³–'),(622,3,98,'æ—‹è½‰æŽƒæŠŠ'),(623,3,99,'é¹½é…¸é›²éœ§'),(624,3,100,'æ”¹è‰¯é­”æ³•æ˜Ÿå½ˆ'),(625,3,101,'ç†”å·–è—¥ç“¶'),(626,3,102,'é­”é“å­¸è€…çš®ç”²å°ˆç²¾'),(627,3,103,'åé‡åŠ›è£ç½®'),(628,3,104,'å†°éœœé‘½å­”è»Š'),(629,3,105,'ç‰¹æ–¯æ‹‰ç·šåœˆ'),(630,3,106,'æš´ç‚ŽåŠ ç†±çˆ'),(631,3,107,'å…ƒç´ å¸«å¸ƒç”²å°ˆç²¾'),(632,3,108,'å¬å–šå¸«å¸ƒç”²å°ˆç²¾'),(633,3,109,'èžåˆå·¥è—'),(634,3,110,'æˆåŠŸé æ„Ÿ'),(635,3,111,'å…‰é›»å†°ç‰†'),(636,3,112,'æµæ˜Ÿé›·é€£æ“Š'),(637,3,113,'è™›ç„¡ç«å±±'),(638,3,114,'å½ˆè·³æ—‹è½‰æŽƒæŠŠ'),(639,3,115,'è¶…ç´šè’¼è …æ‹'),(640,3,116,'å¬å–šç¸æ·¨åŒ–'),(641,3,117,'ç‚«ç´‹ç¢Žéœ¸'),(642,3,118,'å¥‘ç´„å¬å–š : æ†¤æ€’çš„æ¡‘å¾·'),(643,3,119,'ç²¾éˆå¬å–š : æ‹‰ç‰¹åˆ©äºž'),(644,3,120,'ç²¾éˆå¬å–š : ç‘Ÿåˆ©æ–¯ç‰¹'),(645,3,121,'ç²¾éˆå¬å–š : å¸Œå¾·'),(646,3,122,'ç²¾éˆå¬å–š : è‰¾éº—è¥¿å©­'),(647,3,123,'ç‚«ç´‹èžåˆ'),(648,3,124,'å¼·åˆ¶ - ç‚«ç´‹èžåˆ'),(649,3,125,'é›™é‡éŒ˜æ“Š'),(650,3,127,'å®šæ™‚ç‚¸å½ˆ'),(651,3,129,'å¬å–šè§£é™¤'),(652,3,130,'é€£æ“Šç²¾é€š'),(653,3,140,'å¼·åŒ– - é­”æ³•è­·ç›¾'),(654,3,141,'å¼·åŒ– - å…‰é›»é°»'),(655,3,142,'å¼·åŒ– - éž­æ’»'),(656,3,143,'å¼·åŒ– - é å¤é­”æ³•æ›¸'),(657,3,144,'å¼·åŒ– - å†°éœœé›ªäºº'),(658,3,145,'å¼·åŒ– - é­”æ³•ç§€'),(659,3,146,'å¼·åŒ– - è½èŠ±æŽŒ'),(660,3,147,'å¼·åŒ– - æ›¿èº«è‰äºº'),(661,3,148,'å¼·åŒ– - å¹¸é‹æ£’æ£’ç³–'),(662,3,149,'å¼·åŒ– - æ”¹è‰¯é­”æ³•æ˜Ÿå½ˆ'),(663,3,150,'å¼·åŒ– - é­”åŠ›å°è¨˜'),(664,3,151,'å¼·åŒ– - ä¸‹ç´šç²¾éˆ'),(665,3,152,'å¼·åŒ– - å‚‘å…‹é™è‡¨'),(666,3,153,'å¼·åŒ– - è‡ªå‹•ç‚«ç´‹'),(667,3,154,'å¼·åŒ– - è™›ç„¡ä¹‹çƒ'),(668,3,155,'å¼·åŒ– - åœ“èˆžæ£'),(669,3,156,'å¼·åŒ– - ç‚«ç´‹'),(670,3,157,'å¼·åŒ– - å…ƒç´ é»žç‡ƒ'),(671,3,158,'å¼·åŒ– - æ¥µå†°ç››å®´'),(672,3,159,'å¼·åŒ– - å¥‘ç´„å¬å–š : èµ«å¾·'),(673,3,160,'å¼·åŒ– - å¥‘ç´„å¬å–š : éœ²æ˜“'),(674,3,161,'å¼·åŒ– - ç²¾éˆå¬å–š : ä¼Šä¼½'),(675,3,162,'å¼·åŒ– - å¼·è¥²æµæ˜Ÿæ‰“'),(676,3,163,'å¼·åŒ– - æŒ‘é‡äººå¶ : èˆ’éœ²'),(677,3,164,'å¼·åŒ– - åé‡åŠ›è£ç½®'),(678,3,165,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(679,3,166,'å¼·åŒ– - å¥‘ç´„å¬å–š : é­”ç•Œ'),(680,3,169,'åŽè·³'),(681,3,172,'è¼•ç”²ç²¾é€š'),(682,3,173,'é‡ç”²ç²¾é€š'),(683,3,174,'åŸºç¤Žç²¾é€š'),(684,3,175,'èºç¿”'),(685,3,176,'é å¤è¨˜æ†¶'),(686,3,177,'æŠ•æ“²ç²¾é€š'),(687,3,178,'ç‰©ç†èƒŒæ“Š'),(688,3,179,'ç‰©å“åˆ†è§£'),(689,3,180,'ä¸å±ˆæ„å¿—'),(690,3,181,'ç²¾å·¥'),(691,3,182,'ç´¡ç¹”'),(692,3,183,'æ©Ÿæ¢°'),(693,3,184,'ç…‰é‡‘'),(694,3,185,'çš®ç”²ç²¾é€š'),(695,3,186,'ç‰©ç†æš´æ“Š'),(696,3,187,'å¸ƒç”²ç²¾é€š'),(697,3,188,'é­”æ³•æš´æ“Š'),(698,3,189,'é­”æ³•èƒŒæ“Š'),(699,3,190,'å—èº«è¹²ä¼'),(700,3,191,'é­”æ³•è³¦äºˆ'),(701,3,192,'è£½ä½œå¬å–šäººå¶'),(702,3,193,'éŠé‡‘è¡“'),(703,3,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(704,3,195,'ç”Ÿå‘½ä¹‹æº'),(705,3,196,'æ¿ç”²ç²¾é€š'),(706,3,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(707,3,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(708,3,201,'æ¥µé€Ÿæˆé•·'),(709,3,210,'å¼·åŒ– - å¤©æ“Š'),(710,3,211,'å¼·åŒ– - æš—å½±å¤œè²“'),(711,3,212,'å¼·åŒ– - é¾ç‰™'),(712,3,213,'å¼·åŒ– - é­”æ³•æ˜Ÿå½ˆ'),(713,3,214,'å¼·åŒ– - çƒˆç„°è¡æ“Š'),(714,3,215,'å¼·åŒ– - é›·æ—‹'),(715,3,216,'å¼·åŒ– - å†°ç‰†'),(716,3,217,'å¼·åŒ– - å¤©é›·'),(717,3,218,'å¼·åŒ– - é»‘æ´ž'),(718,3,219,'å¼·åŒ– - ç‚«ç´‹ç™¼å°„'),(719,3,221,'å¼·åŒ– - ç‚«ç´‹å¼·å£“'),(720,3,222,'å¼·åŒ– - é›™é‡éŒ˜æ“Š'),(721,3,223,'å¼·åŒ– - ç‚«ç´‹èžåˆ'),(722,3,224,'å¼·åŒ– - æµæ˜Ÿé–ƒå½±æ“Š'),(723,3,225,'å¼·åŒ– - ç¢Žéœ¸'),(724,3,226,'å¼·åŒ– - ç…Œé¾åƒæœˆåˆ€'),(725,3,227,'å¼·åŒ– - å®šæ™‚ç‚¸å½ˆ'),(726,3,228,'å¼·åŒ– - æš—å½±æ–—ç¯·'),(727,3,229,'å¼·åŒ– - æ—‹è½‰æŽƒæŠŠ'),(728,3,230,'å¼·åŒ– - é¹½é…¸é›²éœ§'),(729,3,231,'å¼·åŒ– - è®Šç•°è’¼è …æ‹'),(730,3,232,'å¼·åŒ– - ç†”å·–è—¥ç“¶'),(731,3,233,'å¼·åŒ– - å†°éœœé‘½å­”è»Š'),(732,3,234,'å¼·åŒ– - ç‰¹æ–¯æ‹‰ç·šåœˆ'),(733,3,235,'å¼·åŒ– - æš´ç‚ŽåŠ ç†±çˆ'),(734,3,236,'å¼·åŒ– - ç²¾éˆå¬å–š : äº¡é­‚'),(735,3,237,'å¼·åŒ– - ç²¾éˆå¬å–š : æ¥µå…‰'),(736,3,238,'å¼·åŒ– - ç²¾éˆå¬å–š : å†°å½±'),(737,3,239,'å¼·åŒ– - ç²¾éˆå¬å–š : ç«ç„°'),(738,3,240,'å¼·åŒ– - å¥‘ç´„å¬å–š : å¼—åˆ©'),(739,3,241,'å¼·åŒ– - å¥‘ç´„å¬å–š : é»‘é¨Ž'),(740,3,245,'çƒæ´›æ³¢æ´›æ–¯ä¹‹ç’°'),(741,3,246,'æ˜Ÿç´‹éš•çˆ†'),(742,3,247,'ä½¿å¾’åŒ–èº«'),(743,4,1,'ç©ºæ–¬æ‰“'),(744,4,2,'ä¿¯è¡'),(745,4,3,'æ“ºå‹•'),(746,4,4,'æ¥µé€Ÿé¢¶é¢¨æ‹³'),(747,4,5,'ç–¾ç©ºæ—‹é¢¨ç ´'),(748,4,7,'æ­¦å™¨ç¥ç¦'),(749,4,8,'è™Žè¥²'),(750,4,10,'åŒ–é­”'),(751,4,11,'è½é³³éŒ˜'),(752,4,13,'æ„å¿µé©…å‹•'),(753,4,14,'æŠ€å·§ç²¾é€š'),(754,4,15,'æˆ°ç’°ç²¾é€š'),(755,4,16,'æ‹³æŠ€ç²¾é€š'),(756,4,17,'çµ„åˆç²¾é€š'),(757,4,18,'ç¡¬æ‹³ç²¾é€š'),(758,4,19,'å¤©ç±Ÿä¹‹éŸ³'),(759,4,20,'å®ˆè­·å¾½ç« '),(760,4,21,'ç”Ÿå‘½æ³‰æº'),(761,4,22,'è–å…‰å®ˆè­·'),(762,4,23,'å…‰ä¹‹å¾©ä»‡'),(763,4,24,'å¤©å ‚è«§éŸ³'),(764,4,25,'éˆé­‚çŠ§ç‰²'),(765,4,26,'è–ç™’ä¹‹é¢¨'),(766,4,27,'è–å…‰æ²ç›¾'),(767,4,28,'è–å…‰çƒ'),(768,4,29,'æ‹³æ°£'),(769,4,30,'ç¥žè–åæ“Š'),(770,4,31,'è–æ‹³é€£æ“Š'),(771,4,33,'ç ´ç¢Žä¹‹æ¶'),(772,4,34,'è–é¨Žå£«æ¿ç”²å°ˆç²¾'),(773,4,35,'å¹»å½±åŒ–èº«'),(774,4,36,'é›™é‡å¹»å½±'),(775,4,37,'å¤©è­´é¢¶é¢¨'),(776,4,38,'ç ´é­”ç¬¦'),(777,4,39,'å£“åˆ¶ç¬¦'),(778,4,40,'è½é›·ç¬¦'),(779,4,41,'æ˜Ÿè½æ‰“'),(780,4,42,'æ€¥é€Ÿé–ƒé¿'),(781,4,43,'å…‰ä¹‹æ‹³åˆƒ'),(782,4,45,'æ¦®è­½ç¥ç¦'),(783,4,47,'è„ˆè¼ª : çƒˆç„°'),(784,4,48,'è„ˆè¼ª : æ›œæ—¥'),(785,4,49,'ç‹‚äº‚éŒ˜æ“Š'),(786,4,50,'å·¨æ—‹é¢¨'),(787,4,51,'ç·©æ…¢ç™’åˆ'),(788,4,52,'æ·¨åŒ–'),(789,4,53,'å¤©ä½¿ç¥ç¦'),(790,4,54,'ç¥žçš„æ©è³œ'),(791,4,55,'å¿«é€Ÿç™’åˆ'),(792,4,56,'ä¿¯è¡ç›´æ‹³'),(793,4,57,'ä¿¯è¡è…¹æ‹³'),(794,4,58,'ä¿¯è¡ç¿”æ‹³'),(795,4,61,'ç›´æ‹³è¡æ“Š'),(796,4,63,'å‹¾æ‹³è¿½æ“Š'),(797,4,64,'æƒ¡é­”ä¹‹æ‰‹'),(798,4,65,'å¼·åˆ¶ - æƒ¡é­”ä¹‹æ‰‹'),(799,4,66,'æ½›é¾'),(800,4,67,'é©…é­”éœ‡æ‡¾'),(801,4,68,'é©…é­”å¸«å¸ƒç”²å°ˆç²¾'),(802,4,69,'å¼ç¥ž : çŽ„æ­¦'),(803,4,70,'å¼ç¥ž : ç™½è™Ž'),(804,4,73,'å‹åˆ©ä¹‹çŸ›'),(805,4,74,'æ‡ºæ‚”ä¹‹éŽš'),(806,4,75,'ç¥žè–çµ„åˆæ‹³'),(807,4,76,'è–æ‹³æ¶æ“Š'),(808,4,77,'çž¬æ‹³'),(809,4,78,'åˆºæ‹³çŒ›æ“Š'),(810,4,81,'æ­£ç¾©å¯©åˆ¤'),(811,4,82,'å·¨å…µç²¾é€š'),(812,4,83,'æˆ°æ–§ç²¾é€š'),(813,4,84,'å¤©å•Ÿä¹‹ç '),(814,4,85,'ç–¾é¢¨æ‰“'),(815,4,86,'ä¿¡å¿µå…‰ç’°'),(816,4,87,'æ¥µé™ç‡ƒç‡’'),(817,4,88,'ç„¡é›™æ“Š'),(818,4,89,'é¬¥å¿—æ•£ç™¼'),(819,4,90,'æ³¯æ»…ç¥žæ“Š'),(820,4,91,'è—æ‹³è–ä½¿çš„è¼•ç”²ç²¾é€š'),(821,4,92,'é©…é­”å¸«æ¿ç”²å°ˆç²¾'),(822,4,93,'è’¼é¾æ“Š'),(823,4,96,'é©…é­”å¸«é‡ç”²å°ˆç²¾'),(824,4,97,'å‹‡æ°£æ©å¯µ'),(825,4,98,'å®ˆè­·æ©è³œ'),(826,4,99,'å‡å¤©é™£'),(827,4,100,'é»‘æš—åˆ‡å‰²'),(828,4,101,'å¼ç¥ž : æ®¤'),(829,4,103,'åˆºæ‹³ç‹‚æ“Š'),(830,4,104,'ç ´é­‚çµ„åˆæ‹³'),(831,4,105,'ç‹‚æš´éŒ˜æ“Š'),(832,4,106,'æœ±é›€ç¬¦'),(833,4,107,'è–å…‰åå­—'),(834,4,108,'è–å…‰ç‰ç’ƒç¢Ž'),(835,4,109,'é›™å­æ²ç›¾'),(836,4,110,'å¼ç¥ž : çœŸçŽ„æ­¦'),(837,4,111,'æ–·ç©ºéŒ˜æ“Š'),(838,4,113,'è¿´æ—‹é£›é®'),(839,4,114,'é®åˆ€ç²¾é€š'),(840,4,115,'åŽ„é‹ä¹‹è¼ª'),(841,4,116,'å¾©ä»‡ä¹‹åˆº'),(842,4,117,'é»‘æš—ä¹‹è§¸'),(843,4,118,'è£‚åœ°æ¶'),(844,4,119,'é­”åŒ– : æœ«æ—¥å¯©åˆ¤è€…'),(845,4,120,'è™•åˆ‘'),(846,4,121,'æƒ¡é­”è©›å’’'),(847,4,122,'æƒ¡é­”å–šé†’'),(848,4,123,'æƒ¡é­”ä¹‹åŠ›'),(849,4,124,'æ­»äº¡åˆ‡å‰²'),(850,4,125,'é»‘æš—æ¬Šèƒ½'),(851,4,126,'å¾©ä»‡è€…é‡ç”²å°ˆç²¾'),(852,4,131,'å¢®è½ä¹‹é­‚'),(853,4,133,'åœ°ç„ä¹‹é–€'),(854,4,134,'æœ«æ—¥æµ©åŠ«'),(855,4,140,'å¼·åŒ– - ç·©æ…¢ç™’åˆ'),(856,4,141,'å¼·åŒ– - ç›´æ‹³è¡æ“Š'),(857,4,142,'å¼·åŒ– - è½é³³éŒ˜'),(858,4,143,'å¼·åŒ– - æƒ¡é­”ä¹‹æ‰‹'),(859,4,144,'å¼·åŒ– - å‹åˆ©ä¹‹çŸ›'),(860,4,145,'å¼·åŒ– - å…‰ä¹‹å¾©ä»‡'),(861,4,146,'å¼·åŒ– - ä¿¯è¡ç›´æ‹³'),(862,4,147,'å¼·åŒ– - æ„å¿µé©…å‹•'),(863,4,148,'å¼·åŒ– - å£“åˆ¶ç¬¦'),(864,4,149,'å¼·åŒ– - å·¨æ—‹é¢¨'),(865,4,150,'å¼·åŒ– - è–æ‹³é€£æ“Š'),(866,4,151,'å¼·åŒ– - æ·¨åŒ–'),(867,4,152,'å¼·åŒ– - æ‡ºæ‚”ä¹‹æ§Œ'),(868,4,153,'å¼·åŒ– - ä¿¯è¡è…¹æ‹³'),(869,4,154,'å¼·åŒ– - å¤©è­´é¢¶é¢¨'),(870,4,155,'å¼·åŒ– - å‡å¤©é™£'),(871,4,156,'å¼·åŒ– - ç–¾ç©ºæ—‹é¢¨ç ´'),(872,4,157,'å¼·åŒ– - ç–¾é¢¨æ‰“'),(873,4,158,'å¼·åŒ– - å¼ç¥ž : ç™½è™Ž'),(874,4,159,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(875,4,160,'å¼·åŒ– - ç ´é­”ç¬¦'),(876,4,161,'å¼·åŒ– - æ­»äº¡åˆ‡å‰²'),(877,4,162,'å¼·åŒ– - æƒ¡é­”ä¹‹åŠ›'),(878,4,163,'å¼·åŒ– - è£‚åœ°æ¶'),(879,4,164,'å¼·åŒ– - åŽ„é‹ä¹‹è¼ª'),(880,4,165,'å¼·åŒ– - é»‘æš—ä¹‹è§¸'),(881,4,166,'å¼·åŒ– - è–å…‰çƒ'),(882,4,167,'å¼·åŒ– - è–å…‰åå­—'),(883,4,168,'å¼·åŒ– - çž¬æ‹³'),(884,4,169,'åŽè·³'),(885,4,172,'è¼•ç”²ç²¾é€š'),(886,4,173,'é‡ç”²ç²¾é€š'),(887,4,174,'åŸºç¤Žç²¾é€š'),(888,4,175,'èºç¿”'),(889,4,176,'é å¤è¨˜æ†¶'),(890,4,177,'æŠ•æ“²ç²¾é€š'),(891,4,178,'ç‰©ç†èƒŒæ“Š'),(892,4,179,'ç‰©å“åˆ†è§£'),(893,4,180,'ä¸å±ˆæ„å¿—'),(894,4,181,'ç²¾å·¥'),(895,4,182,'ç´¡ç¹”'),(896,4,183,'æ©Ÿæ¢°'),(897,4,184,'ç…‰é‡‘'),(898,4,185,'çš®ç”²ç²¾é€š'),(899,4,186,'ç‰©ç†æš´æ“Š'),(900,4,187,'å¸ƒç”²ç²¾é€š'),(901,4,188,'é­”æ³•æš´æ“Š'),(902,4,189,'é­”æ³•èƒŒæ“Š'),(903,4,190,'å—èº«è¹²ä¼'),(904,4,191,'é­”æ³•è³¦äºˆ'),(905,4,192,'è£½ä½œå¬å–šäººå¶'),(906,4,193,'éŠé‡‘è¡“'),(907,4,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(908,4,195,'ç”Ÿå‘½ä¹‹æº'),(909,4,196,'æ¿ç”²ç²¾é€š'),(910,4,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(911,4,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(912,4,201,'æ¥µé€Ÿæˆé•·'),(913,4,210,'å¼·åŒ– - ç©ºæ–¬æ‰“'),(914,4,211,'å¼·åŒ– - è™Žè¥²'),(915,4,212,'å¼·åŒ– - å‹¾æ‹³è¿½æ“Š'),(916,4,213,'å¼·åŒ– - å…‰ä¹‹æ‹³åˆƒ'),(917,4,214,'å¼·åŒ– - è–å…‰æ²ç›¾ '),(918,4,215,'å¼·åŒ– - æ­£ç¾©å¯©åˆ¤'),(919,4,216,'å¼·åŒ– - æ–·ç©ºéŒ˜æ“Š'),(920,4,217,'å¼·åŒ– - é»‘æš—åˆ‡å‰²'),(921,4,218,'å¼·åŒ– - å¼ç¥ž : æ®¤'),(922,4,219,'å¼·åŒ– - æ˜Ÿè½æ‰“'),(923,4,220,'å¼·åŒ– - æœ±é›€ç¬¦'),(924,4,221,'å¼·åŒ– - ç‹‚äº‚éŒ˜æ“Š'),(925,4,223,'å¼·åŒ– - ç„¡é›™æ“Š'),(926,4,224,'å¼·åŒ– - è–æ‹³æ¶æ“Š'),(927,4,225,'å¼·åŒ– - ä¿¯è¡ç¿”æ‹³'),(928,4,227,'å¼·åŒ– - ç¥žè–åæ“Š'),(929,4,228,'å¼·åŒ– - ç ´ç¢Žä¹‹æ¶'),(930,4,229,'å¼·åŒ– - åˆºæ‹³çŒ›æ“Š'),(931,4,230,'å¼·åŒ– - ç¥žè–çµ„åˆæ‹³'),(932,4,231,'å¼·åŒ– - æ¥µé€Ÿé¢¶é¢¨æ‹³'),(933,4,232,'å¼·åŒ– - è¿´æ—‹é£›é®'),(934,4,233,'å¼·åŒ– - å¾©ä»‡ä¹‹åˆº'),(935,4,234,'å¼·åŒ– - é»‘æš—æ¬Šèƒ½'),(936,4,235,'å¼·åŒ– - å¼ç¥ž : çŽ„æ­¦'),(937,4,236,'å¼·åŒ– - è½é›·ç¬¦'),(938,4,237,'ç¥žè–æ´—ç¦®:ä¿¡ä»°ä¹‹ç¿¼'),(939,4,238,'çœŸé¾ç„šå¤©'),(940,5,1,'çˆ†ç‚Žå½ˆ'),(941,5,2,'å†°å‡å½ˆ'),(942,5,3,'ä¸Šæ—‹è¸¢'),(943,5,4,'ç‘ªéº—è“®çŽ«ç‘°'),(944,5,5,'çˆ†é ­ä¸€æ“Š'),(945,5,6,'é‡˜åˆºå°„'),(946,5,7,'åˆºè¸¢'),(947,5,8,'èµ·èº«ä¸Šæ—‹è¸¢'),(948,5,9,'æ§èˆž'),(949,5,10,'é ç¨‹æ ¼æ“‹'),(950,5,11,'å¿«é€Ÿæ‹”æ§'),(951,5,12,'M-137æ ¼æž—æ©Ÿæ§'),(952,5,13,'M-3å™´ç«å™¨'),(953,5,14,'BBQ'),(954,5,15,'ç§»å‹•å°„æ“Š'),(955,5,20,'å›žé ­ä¸€æ“Š'),(956,5,21,'é‡ç«å™¨ç²¾é€š'),(957,5,22,'å·¦è¼ªç²¾é€š'),(958,5,23,'å¿«é€Ÿå¡«è£'),(959,5,26,'å¾©ä»‡åæ“Š'),(960,5,27,'RX-78è¿½æ“Šè€…'),(961,5,28,'Ez-8è‡ªçˆ†è€…'),(962,5,29,'Ex-Sæ¯’è›‡ç‚®'),(963,5,30,'éŠ€å½ˆ'),(964,5,31,'å½ˆè—¥æ”¹è‰¯'),(965,5,32,'ä¸‰é‡æŽ§åˆ¶'),(966,5,33,'ç©ºä¸­å°„æ“Š'),(967,5,34,'é‡ç«å™¨æ‹”æ“Š'),(968,5,35,'éŸ³é€Ÿæˆªæ“Š'),(969,5,36,'èšç„¦å™´ç«å™¨'),(970,5,37,'æµ®ç©ºéŸ'),(971,5,38,'FM-31æ¦´å½ˆç™¼å°„å™¨'),(972,5,39,'é³å°„ç‚®'),(973,5,40,'åå¦å…‹ç‚®'),(974,5,41,'è“„é›»é³å°„ç‚®'),(975,5,42,'å—œæˆ°è¿½æ“Šè€…'),(976,5,43,'å½è£'),(977,5,44,'é‡ç«å™¨å¥§ç¾©'),(978,5,45,'é‡å­çˆ†å½ˆ'),(979,5,46,'æ©Ÿæ¢°æ”¹è‰¯'),(980,5,47,'æµ®ç©ºå½ˆ'),(981,5,48,'äº¤å‰å°„æ“Š'),(982,5,49,'å½ˆåŒ£æ“´å……'),(983,5,50,'æ©Ÿæ¢°å¼•çˆ†'),(984,5,51,'é›™é·¹è¿´æ—‹'),(985,5,52,'ç ´ç”²å½ˆ'),(986,5,53,'å…‰å­çˆ†å½ˆ'),(987,5,55,'éŠä¿ çš®ç”²å°ˆç²¾'),(988,5,56,'G-14 æ‰‹é›·'),(989,5,57,'G-35L æ„Ÿé›»æ‰‹é›·'),(990,5,58,'G-18C å†°å‡æ‰‹é›·'),(991,5,59,'ç©ºæŠ•æ”¯æ´'),(992,5,60,'æ­»äº¡å·¦è¼ª'),(993,5,61,'é­”å½ˆå°„æ‰‹çš®ç”²å°ˆç²¾'),(994,5,62,'æ½›èƒ½çˆ†ç™¼'),(995,5,63,'ç©ºæˆ°æ©Ÿæ¢° : ç‹‚é¢¨'),(996,5,71,'X-1 å£“ç¸®é‡å­ç‚®'),(997,5,72,'å¤šé‡çˆ†é ­'),(998,5,73,'åŠ è¾²ç‚®'),(999,5,74,'å¼·åˆ¶ - åŠ è¾²ç‚®'),(1000,5,75,'FM-92 mk2æ¦´å½ˆ'),(1001,5,76,'é–ƒæ“Šåœ°é›·'),(1002,5,77,'C4é ç«¯ç‚¸å½ˆ'),(1003,5,78,'å°¼çˆ¾ç‹™æ“Š'),(1004,5,79,'G-1æŸ¯æ´›ç´'),(1005,5,80,'æ”¹è£ :  G-2 æ—‹é›·'),(1006,5,81,'æ”¹è£ : G-3 çŒ›ç¦½'),(1007,5,82,'å½ˆè—¥æ”¯æ´'),(1008,5,83,'æ””æˆªæ©Ÿå·¥å» '),(1009,5,91,'æ©Ÿæ¢°å¸«å¸ƒç”²å°ˆç²¾'),(1010,5,92,'é‡ç‚®æ‰‹é‡ç”²å°ˆç²¾'),(1011,5,93,'é‡ç«å™¨éŽè¼‰'),(1012,5,94,'éš±æ™¦ä¹‹åˆƒ'),(1013,5,95,'Gç³»æ“´å¼µ'),(1014,5,96,'æ”¹è£ : G-0æˆ°çˆ­é ˜ä¸»'),(1015,5,97,'é å¤ç²’å­ç‚®'),(1016,5,98,'EMPç£æš´'),(1017,5,99,'å½ˆè—¥å¼·åŒ–'),(1018,5,100,'é›™æ§æ¥µèˆžåˆƒ'),(1019,5,101,'ç†¾ç„°æˆªæ“Š'),(1020,5,102,'C4é£›é€Ÿç‚¸å½ˆ'),(1021,5,103,'M-61åœ°é›·'),(1022,5,104,'æ¥µé™å¤šé‡çˆ†é ­'),(1023,5,105,'Ez-10åæ“Šè€…'),(1024,5,106,'Ex-S Zeroæ¯’è›‡ç‚®'),(1025,5,107,'èšç„¦å¯’å†°å™´å°„å™¨'),(1026,5,108,'FM-92 mk2 SWæ¦´å½ˆ'),(1027,5,109,'ç ´è£‚å°„æ“Š'),(1028,5,110,'æ­¥æ§ç²¾é€š'),(1029,5,140,'å¼·åŒ– - çˆ†é ­ä¸€æ“Š'),(1030,5,141,'å¼·åŒ– - BBQ'),(1031,5,142,'å¼·åŒ– - RX-78è¿½æ“Šè€…'),(1032,5,143,'å¼·åŒ– - éŠ€å½ˆ'),(1033,5,144,'å¼·åŒ– - é ç¨‹æ ¼æ“‹'),(1034,5,145,'å¼·åŒ– - é‡˜åˆºå°„'),(1035,5,146,'å¼·åŒ– - M-3å™´ç«å™¨'),(1036,5,147,'å¼·åŒ– - åå¦å…‹ç‚®'),(1037,5,148,'å¼·åŒ– - æ©Ÿæ¢°å¼•çˆ†'),(1038,5,149,'å¼·åŒ– - G-1æŸ¯æ´›ç´'),(1039,5,150,'å¼·åŒ– - äº¤å‰å°„æ“Š'),(1040,5,151,'å¼·åŒ– - å½ˆåŒ£æ“´å……'),(1041,5,152,'é­”æ”»è½‰æ›'),(1042,5,153,'å¼·åŒ– - åˆºè¸¢'),(1043,5,154,'å¼·åŒ– - æ§èˆž'),(1044,5,155,'å¼·åŒ– - G-14æ‰‹é›·'),(1045,5,156,'å¼·åŒ– - å…‰å­çˆ†å½ˆ'),(1046,5,157,'å¼·åŒ– - Ez-8è‡ªçˆ†è€…'),(1047,5,158,'å¼·åŒ– - æ””æˆªæ©Ÿå·¥å» '),(1048,5,159,'å¼·åŒ– - M-137æ ¼æž—æ©Ÿæ§'),(1049,5,160,'å¼·åŒ– - FM-92 mk2æ¦´å½ˆ'),(1050,5,161,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(1051,5,162,'å¼·åŒ– - çˆ†ç‚Žå½ˆ'),(1052,5,163,'å¼·åŒ– - å†°å‡å½ˆ'),(1053,5,164,'å¼·åŒ– - å¾©ä»‡åæ“Š'),(1054,5,166,'å¼·åŒ– - ä¸Šæ—‹è¸¢'),(1055,5,167,'å¼·åŒ– - æµ®ç©ºå½ˆ'),(1056,5,168,'å¼·åŒ– - ç‘ªéº—è“®çŽ«ç‘°'),(1057,5,169,'åŽè·³'),(1058,5,172,'è¼•ç”²ç²¾é€š'),(1059,5,173,'é‡ç”²ç²¾é€š'),(1060,5,174,'åŸºç¤Žç²¾é€š'),(1061,5,175,'èºç¿”'),(1062,5,176,'é å¤è¨˜æ†¶'),(1063,5,177,'æŠ•æ“²ç²¾é€š'),(1064,5,178,'ç‰©ç†èƒŒæ“Š'),(1065,5,179,'ç‰©å“åˆ†è§£'),(1066,5,180,'ä¸å±ˆæ„å¿—'),(1067,5,181,'ç²¾å·¥'),(1068,5,182,'ç´¡ç¹”'),(1069,5,183,'æ©Ÿæ¢°'),(1070,5,184,'ç…‰é‡‘'),(1071,5,185,'çš®ç”²ç²¾é€š'),(1072,5,186,'ç‰©ç†æš´æ“Š'),(1073,5,187,'å¸ƒç”²ç²¾é€š'),(1074,5,188,'é­”æ³•æš´æ“Š'),(1075,5,189,'é­”æ³•èƒŒæ“Š'),(1076,5,190,'å—èº«è¹²ä¼'),(1077,5,191,'é­”æ³•è³¦äºˆ'),(1078,5,192,'è£½ä½œå¬å–šäººå¶'),(1079,5,193,'éŠé‡‘è¡“'),(1080,5,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(1081,5,195,'ç”Ÿå‘½ä¹‹æº'),(1082,5,196,'æ¿ç”²ç²¾é€š'),(1083,5,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(1084,5,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(1085,5,201,'æ¥µé€Ÿæˆé•·'),(1086,5,211,'å¼·åŒ– - éŸ³é€Ÿæˆªæ“Š'),(1087,5,212,'å¼·åŒ– - ç§»å‹•å°„æ“Š'),(1088,5,213,'å¼·åŒ– - é›™é·¹è¿´æ—‹'),(1089,5,214,'å¼·åŒ– - å¤šé‡çˆ†é ­'),(1090,5,215,'å¼·åŒ– - é³å°„ç‚®'),(1091,5,216,'å¼·åŒ– - X-1 å£“ç¸®é‡å­ç‚®'),(1092,5,217,'å¼·åŒ– - åŠ è¾²ç‚®'),(1093,5,218,'å¼·åŒ– - èšç„¦å™´ç«å™¨'),(1094,5,219,'å¼·åŒ– - æ”¹è£ : G-2 æ—‹é›·'),(1095,5,220,'å¼·åŒ– - æ”¹è£ : G-3 çŒ›ç¦½'),(1096,5,221,'å¼·åŒ– - é‡å­çˆ†å½ˆ'),(1097,5,222,'å¼·åŒ– - ç©ºæˆ°æ©Ÿæ¢° : ç‹‚é¢¨'),(1098,5,223,'å¼·åŒ– - G35L æ„Ÿé›»æ‰‹é›·'),(1099,5,224,'å¼·åŒ– - G18C å†°å‡æ‰‹é›·'),(1100,5,225,'å¼·åŒ– - ç ´ç”²å½ˆ'),(1101,5,226,'å¼·åŒ– - ç ´è£‚å°„æ“Š'),(1102,5,227,'å¼·åŒ– - é–ƒæ“Šåœ°é›·'),(1103,5,228,'å¼·åŒ– - C4 é ç«¯ç‚¸å½ˆ'),(1104,5,229,'å¼·åŒ– - å°¼çˆ¾ç‹™æ“Š'),(1105,5,230,'å¼·åŒ– - Ex-S æ¯’è›‡ç‚®'),(1106,5,231,'å¼·åŒ– - ç©ºæŠ•æ”¯æ´'),(1107,5,232,'è¡€èˆžç¥­'),(1108,5,233,'å£“åˆ¶å°„æ“Š'),(1109,5,234,'ç«åŠ›å…¨é–‹'),(1110,5,235,'PT15åŽŸå§‹åž‹å£“ç¸®ç‚®'),(1111,5,236,'æ±ºæˆ°ä¹‹æ—¥'),(1112,5,237,'G96ç†±å£“æ‰‹é›·'),(1113,6,1,'ç¿”æ“Š'),(1114,6,2,'åˆ‡å‰²'),(1115,6,3,'å¼§å…‰é–ƒ'),(1116,6,4,'ç–¾ç©ºè¸'),(1117,6,5,'ç„°åˆƒ'),(1118,6,6,'å¿æ³• : é£›é¼ '),(1119,6,7,'å½±è¥²'),(1120,6,8,'å¤©èª…'),(1121,6,9,'çµ‚çµè¿½æ“Š'),(1122,6,16,'çµ•æ®ºæ–¬'),(1123,6,18,'ç©ºèº'),(1124,6,19,'ç–¾é¦³'),(1125,6,21,'æš—é­‚æ³¢'),(1126,6,22,'éª¨ç›¾'),(1127,6,23,'è©›å’’ä¹‹ç®­'),(1128,6,24,'æ‰‹è£¡åŠ'),(1129,6,25,'å¿æ³• : å½±åˆ†èº«'),(1130,6,26,'ç¢Žè¸'),(1131,6,27,'é›™åˆƒç©¿åˆº'),(1132,6,29,'åŒ•é¦–ç²¾é€š'),(1133,6,30,'é›™åŠç²¾é€š'),(1134,6,31,'åŠåˆƒé¢¨æš´'),(1135,6,33,'èžºæ—‹ç©¿åˆº'),(1136,6,34,'ç–¾é¢¨äº‚èˆž'),(1137,6,35,'æ­»äº¡ä¹‹çˆª'),(1138,6,36,'ç™¾é¬¼å¤œè¡Œ'),(1139,6,37,'é™è‡¨ : æš´å›å·´æ‹‰å…‹'),(1140,6,38,'æš—é­‚æ³¢'),(1141,6,39,'å·´æ‹‰å…‹çš„é‡Žå¿ƒ'),(1142,6,40,'å·´æ‹‰å…‹çš„æ†¤æ€’'),(1143,6,41,'æ—‹åˆƒ'),(1144,6,43,'å¼§å…‰é€£é–ƒ'),(1145,6,44,'å´æ­¥'),(1146,6,45,'é›·å…‰åˆƒå½±'),(1147,6,47,'çµ•å‘½çž¬ç„æ®º'),(1148,6,49,'æ­»éˆä¹‹æ€¨'),(1149,6,50,'æš—é»‘å„€å¼'),(1150,6,51,'é™è‡¨ : å°¼å¤æ‹‰æ–¯'),(1151,6,52,'é©…ä½¿åƒµå°¸'),(1152,6,53,'æš—å½±è››çµ²é™£'),(1153,6,54,'æœå¾ž'),(1154,6,55,'å¸é­‚æš—å‹æ³¢'),(1155,6,56,'æœˆå¼§'),(1156,6,57,'æœˆè¼ªèˆž'),(1157,6,58,'å± æˆ®ä¹‹æ‡¼'),(1158,6,59,'åƒé­‚ç¥­'),(1159,6,60,'ç›œè³Šçš®ç”²å°ˆç²¾'),(1160,6,61,'åˆºå®¢çš®ç”²å°ˆç²¾'),(1161,6,62,'æ­»éˆè¡“å£«è¼•ç”²å°ˆç²¾'),(1162,6,63,'å¿è€…å¸ƒç”²å°ˆç²¾'),(1163,6,64,'å½±æ­¦è€…çš®ç”²å°ˆç²¾'),(1164,6,74,'æ­»éˆä¹‹ç¸›'),(1165,6,75,'éš•è½èžºæ—‹åˆº'),(1166,6,76,'æ—‹åˆƒè¡æ“Š'),(1167,6,77,'é‡‹é­‚æš—å‹æ³¢'),(1168,6,140,'å¼·åŒ– - æ‰‹è£¡åŠ'),(1169,6,141,'å¼·åŒ– - è©›å’’ä¹‹ç®­'),(1170,6,142,'å¼·åŒ– - å¤©èª…'),(1171,6,143,'å¼·åŒ– - ç–¾ç©ºè¸'),(1172,6,144,'å¼·åŒ– - åŠåˆƒé¢¨æš´'),(1173,6,145,'å¼·åŒ– - çµ‚çµè¿½æ“Š'),(1174,6,146,'å¼·åŒ– - ç™¾é¬¼å¤œè¡Œ'),(1175,6,147,'å¼·åŒ– - æš—å½±è››çµ²é™£'),(1176,6,148,'å¼·åŒ– - å¼§å…‰é–ƒ'),(1177,6,149,'å¼·åŒ– - ç–¾é¢¨äº‚èˆž'),(1178,6,150,'å¼·åŒ– - æš—é­‚æ³¢'),(1179,6,151,'å¼·åŒ– - é™è‡¨ : æš´å›å·´æ‹‰'),(1180,6,152,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(1181,6,153,'å¼·åŒ– - ç¿”æ“Š'),(1182,6,154,'å¼·åŒ– - åˆ‡å‰²'),(1183,6,155,'å¼·åŒ– - ç„°åˆƒ'),(1184,6,156,'å¼·åŒ– - å½±è¥²'),(1185,6,157,'å¼·åŒ– - éª¨ç›¾'),(1186,6,158,'å¼·åŒ– - ç¢Žè¸'),(1187,6,159,'å¼·åŒ– - å¿æ³• : é£›é¼ '),(1188,6,160,'å¼·åŒ– - çµ•å‘½çž¬ç„æ®º'),(1189,6,161,'å¼·åŒ– - èžºæ—‹ç©¿åˆº'),(1190,6,162,'å¼·åŒ– - é›·å…‰åˆƒå½±'),(1191,6,163,'å¼·åŒ– - æ—‹åˆƒ'),(1192,6,164,'å¼·åŒ– - é›™åˆƒç©¿åˆº'),(1193,6,165,'å¼·åŒ– - çµ•æ®ºæ–¬'),(1194,6,169,'åŽè·³'),(1195,6,172,'è¼•ç”²ç²¾é€š'),(1196,6,173,'é‡ç”²ç²¾é€š'),(1197,6,174,'åŸºç¤Žç²¾é€š'),(1198,6,175,'èºç¿”'),(1199,6,176,'é å¤è¨˜æ†¶'),(1200,6,177,'æŠ•æ“²ç²¾é€š'),(1201,6,178,'ç‰©ç†èƒŒæ“Š'),(1202,6,179,'ç‰©å“åˆ†è§£'),(1203,6,180,'ä¸å±ˆæ„å¿—'),(1204,6,181,'ç²¾å·¥'),(1205,6,182,'ç´¡ç¹”'),(1206,6,183,'æ©Ÿæ¢°'),(1207,6,184,'ç…‰é‡‘'),(1208,6,185,'çš®ç”²ç²¾é€š'),(1209,6,186,'ç‰©ç†æš´æ“Š'),(1210,6,187,'å¸ƒç”²ç²¾é€š'),(1211,6,188,'é­”æ³•æš´æ“Š'),(1212,6,189,'é­”æ³•èƒŒæ“Š'),(1213,6,190,'å—èº«è¹²ä¼'),(1214,6,191,'é­”æ³•è³¦äºˆ'),(1215,6,192,'è£½ä½œå¬å–šäººå¶'),(1216,6,193,'éŠé‡‘è¡“'),(1217,6,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(1218,6,195,'ç”Ÿå‘½ä¹‹æº'),(1219,6,196,'æ¿ç”²ç²¾é€š'),(1220,6,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(1221,6,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(1222,6,201,'æ¥µé€Ÿæˆé•·'),(1223,6,210,'å¼·åŒ– - é™è‡¨ : å°¼å¤æ‹‰æ–¯'),(1224,6,211,'å¼·åŒ– - æ­»äº¡ä¹‹çˆª'),(1225,6,212,'å¼·åŒ– - æ­»éˆä¹‹æ€¨'),(1226,6,213,'å¼·åŒ– - å·´æ‹‰å…‹çš„é‡Žå¿ƒ'),(1227,6,214,'å¼·åŒ– - å¸é­‚æš—å‹æ³¢'),(1228,6,215,'å¼·åŒ– - å·´æ‹‰å…‹çš„æ†¤æ€’'),(1229,6,216,'å¼·åŒ– - é©…ä½¿æ®­å°¸'),(1230,6,217,'å¼·åŒ– - å¿æ³• : å½±åˆ†èº«'),(1231,6,218,'å±¬æ€§æ”»æ“Šç²¾é€š'),(1232,6,219,'å±¬æ€§æŠ—æ€§ç²¾é€š'),(1233,7,1,'éµå±±é '),(1234,7,2,'è¹²ä¼'),(1235,7,3,'æ“’æœˆç‚Ž'),(1236,7,4,'ç¢Žéª¨'),(1237,7,5,'åŽè¸¢'),(1238,7,6,'ä¸‹æ®µè¸¢'),(1239,7,7,'é‹¼ç­‹éµéª¨'),(1240,7,8,'åˆ†èº«'),(1241,7,9,'è†æ“Š'),(1242,7,10,'è†æ“Šå¼·åŒ–'),(1243,7,11,'é›·éœ†è†æ“Š'),(1244,7,12,'å¿µæ°£æ³¢'),(1245,7,13,'æ‹‹æ²™'),(1246,7,14,'ä¼è™Žéœ¸çŽ‹æ‹³'),(1247,7,15,'ç…å­å¼'),(1248,7,16,'èžºæ—‹å¿µæ°£å ´'),(1249,7,17,'é·¹è¸'),(1250,7,18,'æµ®ç©ºæ·©é›²è¸¢'),(1251,7,19,'è¡è†'),(1252,7,20,'éœ¸é«”è­·ç”²'),(1253,7,21,'å¼·åˆ¶ - å¿µæ°£æ³¢'),(1254,7,22,'æ‘”æŠ€å¼·åŒ–'),(1255,7,29,'å…‰ä¹‹è¦ªå’Œ'),(1256,7,30,'å…‰ä¹‹å…µåˆƒ'),(1257,7,31,'é¢¨ä¹‹æ°£æ¯'),(1258,7,32,'åŠ‡æ¯’æŠµæŠ—'),(1259,7,33,'èµ°ç«å…¥é­”'),(1260,7,34,'æ‹³å¥—æŽŒæ¡'),(1261,7,35,'å¿µæ°£æ„ŸçŸ¥'),(1262,7,36,'çƒˆæ—¥å…‰è¼'),(1263,7,37,'å¼·æ‹³'),(1264,7,38,'æ¯’ç“¶æŠ•æ“²'),(1265,7,39,'å¼±é»žæ„ŸçŸ¥'),(1266,7,40,'å¿µæ°£ç’°ç¹ž'),(1267,7,41,'çƒˆç„°ç„šæ­¥'),(1268,7,42,'å¿µæ°£ç½©'),(1269,7,43,'é›™é‡æŠ•æ“²'),(1270,7,44,'æŒ‘é‡'),(1271,7,45,'çˆªç²¾é€š'),(1272,7,46,'å‰è¸¢'),(1273,7,49,'æ‹‹æŠ•'),(1274,7,50,'æš´åŠ›æŠ“å–'),(1275,7,51,'æ»‘è¡ŒæŠ“å–'),(1276,7,52,'ç¾…ç¶²æŠ•æ“²'),(1277,7,54,'é‡Žè »è¡æ’ž'),(1278,7,55,'æŠ“è½Ÿç‚®'),(1279,7,56,'æ­¦é¬¥è¼•ç”²å°ˆç²¾'),(1280,7,57,'æŸ”é“å®¶å®¶è¼•ç”²å°ˆç²¾'),(1281,7,58,'æ—‹é¢¨è…¿'),(1282,7,60,'ç£šå¡ŠæŠ•æ“²'),(1283,7,61,'å¼·åˆ¶ - æŠ•æ“²'),(1284,7,62,'ç©ºçµžéŒ˜'),(1285,7,63,'æ­»äº¡æ—‹å¾‹'),(1286,7,65,'çƒˆç„°ç‡ƒç‡’'),(1287,7,67,'å¿µç¸ : å¯©åˆ¤ä¹‹é‡‘é›·è™Ž'),(1288,7,68,'é–ƒé›»ä¹‹èˆž'),(1289,7,69,'å¹»å½±çˆ†ç¢Ž'),(1290,7,73,'è¡—éœ¸é‡ç”²å°ˆç²¾'),(1291,7,74,'ç‹‚ Â· éœ¸çŽ‹æ‹³'),(1292,7,75,'æ¯’é‡æŠ•æ“²'),(1293,7,76,'æ¯’é›·å¼•çˆ†'),(1294,7,77,'è¡€è‰²é¢¨æš´'),(1295,7,78,'è“„å¿µç‚®'),(1296,7,79,'å¿µç¸ : é¾è™Žå˜¯'),(1297,7,80,'è‚˜æ“Š'),(1298,7,81,'æŠ˜é ¸'),(1299,7,82,'çž¬å½±é€£ç’°è¸¢'),(1300,7,83,'ç†¾ç„°æ—‹é¢¨è…¿'),(1301,7,84,'ç–¾é¢¨è¿½æ“Š'),(1302,7,85,'ç–¾é¢¨é€£æ“Š'),(1303,7,86,'é‡‘å‰›ç¢Ž'),(1304,7,87,'éœ¹é‚æ—‹è¸¢'),(1305,7,88,'è£‚çŸ³ç ´å¤©'),(1306,7,89,'åœ°ç„é¢¨ç«è¼ª'),(1307,7,90,'å¿µç¸ : çŒ›è™Žéœ‡åœ°'),(1308,7,91,'æŸ”åŒ–è‚Œè‚‰'),(1309,7,97,'é¬¥æ°£å¸«å¸ƒç”²å°ˆç²¾'),(1310,7,105,'å¤©å´©åœ°è£‚'),(1311,7,106,'èžºæ—‹æ»‘éŸ'),(1312,7,108,'çž¬æ­¥'),(1313,7,109,'æŠ•æ“²å¼·åŒ–'),(1314,7,110,'è‡ªå‹•å¡«å……'),(1315,7,111,'å¿µæ°£ç’°ç¹ž : è¥²'),(1316,7,112,'å¿µæ°£ç’°ç¹ž : ç¦¦'),(1317,7,114,'å¿µä¹‹å¥§ç¾©'),(1318,7,115,'åŠ›ä¹‹å¥§ç¾©'),(1319,7,116,'åƒæ‰‹å¥§ç¾©'),(1320,7,117,'å¿µä¹‹æˆ°çŸ›'),(1321,7,118,'å½—æ˜Ÿè¡æ“Š'),(1322,7,119,'çˆ†ç ´é»çƒ'),(1323,7,120,'è¡é›²å¿µæ°£å ´'),(1324,7,121,'æ­¦è“®è¯'),(1325,7,122,'æ—‹é¢¨ç¢Žå¿ƒè¸¢'),(1326,7,123,'åƒçµ²äº‚èˆž'),(1327,7,124,'éœ¹é‚ä¸‰é‡è¸¢'),(1328,7,125,'å¼·åŒ– - é‡‘å‰›ç¢Ž'),(1329,7,126,'å¼·åŒ– - è†æ“Š'),(1330,7,127,'å¼·åŒ– - å¿µæ°£æ³¢'),(1331,7,128,'å¼·åŒ– - é‹¼ç­‹éµéª¨'),(1332,7,129,'å¼·åŒ– - æ—‹é¢¨è…¿'),(1333,7,130,'å¼·åŒ– - ä¸‹æ®µè¸¢'),(1334,7,131,'å¼·åŒ– - è¹²ä¼'),(1335,7,132,'å¼·åŒ– - æ‹‹æ²™'),(1336,7,133,'å¼·åŒ– - èžºæ—‹å¿µæ°£å ´'),(1337,7,134,'å¼·åŒ– - é›·éœ†è†æ“Š'),(1338,7,135,'å¼·åŒ– - çž¬å½±é€£ç’°è¸¢'),(1339,7,136,'å¼·åŒ– - å¿µç¸ : é¾è™Žå˜¯'),(1340,7,137,'å¼·åŒ– - ç¢Žéª¨'),(1341,7,138,'å¼·åŒ– - èžºæ—‹æ»‘éŸ'),(1342,7,139,'å¼·åŒ– - é–ƒé›»ä¹‹èˆž'),(1343,7,140,'å¼·åŒ– - ç†¾ç„°æ—‹é¢¨è…¿'),(1344,7,141,'å¼·åŒ– - ç¾…ç¶²æŠ•æ“²'),(1345,7,142,'å¼·åŒ– - æŒ‘é‡'),(1346,7,143,'å¼·åŒ– - æ¯’é›·å¼•çˆ†'),(1347,7,144,'å¼·åŒ– - è¡€è‰²é¢¨æš´'),(1348,7,145,'å¼·åŒ– - æŠ˜é ¸'),(1349,7,146,'å¼·åŒ– - é‡Žè »è¡æ’ž'),(1350,7,147,'å¼·åŒ– - åœ°ç„é¢¨ç«è¼ª'),(1351,7,148,'å¼·åŒ– - æµ®ç©ºæ·©é›²è¸¢'),(1352,7,149,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(1353,7,150,'å¼·åŒ– - åŽè¸¢'),(1354,7,151,'å¼·åŒ– - å‰è¸¢'),(1355,7,152,'å¼·åŒ– - åˆ†èº«'),(1356,7,153,'å¼·åŒ– - é·¹è¸'),(1357,7,154,'å¼·åŒ– - å¿µæ°£ç½©'),(1358,7,155,'å¼·åŒ– - å¹»å½±çˆ†ç¢Ž'),(1359,7,156,'å¼·åŒ– - ç…å­å¼'),(1360,7,157,'å¼·åŒ– - å¿µç¸ : çŒ›è™Žéœ‡åœ°'),(1361,7,158,'å¼·åŒ– - å¿µæ°£ç’°ç¹ž : è¥²'),(1362,7,159,'å¼·åŒ– - å¿µæ°£ç’°ç¹ž : ç¦¦'),(1363,7,160,'å¼·åŒ– - è‚˜æ“Š'),(1364,7,161,'å¼·åŒ– - è¡è†'),(1365,7,162,'å¼·åŒ– - éµå±±é '),(1366,7,163,'å¼·åŒ– - æ“’æœˆç‚Ž'),(1367,7,164,'å¼·åŒ– - æ¯’é‡æŠ•æ“²'),(1368,7,165,'å¼·åŒ– - æ¯’ç“¶æŠ•æ“²'),(1369,7,166,'å¼·åŒ– - æ‹‹æŠ•'),(1370,7,167,'å¼·åŒ– - ç©ºçµžéŒ˜'),(1371,7,168,'å¼·åŒ– - éœ¹é‚æ—‹è¸¢'),(1372,7,169,'åŽè·³'),(1373,7,172,'è¼•ç”²ç²¾é€š'),(1374,7,173,'é‡ç”²ç²¾é€š'),(1375,7,174,'åŸºç¤Žç²¾é€š'),(1376,7,175,'èºç¿”'),(1377,7,176,'é å¤è¨˜æ†¶'),(1378,7,177,'æŠ•æ“²ç²¾é€š'),(1379,7,178,'ç‰©ç†èƒŒæ“Š'),(1380,7,179,'ç‰©å“åˆ†è§£'),(1381,7,180,'ä¸å±ˆæ„å¿—'),(1382,7,181,'ç²¾å·¥'),(1383,7,182,'ç´¡ç¹”'),(1384,7,183,'æ©Ÿæ¢°'),(1385,7,184,'ç…‰é‡‘'),(1386,7,185,'çš®ç”²ç²¾é€š'),(1387,7,186,'ç‰©ç†æš´æ“Š'),(1388,7,187,'å¸ƒç”²ç²¾é€š'),(1389,7,188,'é­”æ³•æš´æ“Š'),(1390,7,189,'é­”æ³•èƒŒæ“Š'),(1391,7,190,'å—èº«è¹²ä¼'),(1392,7,191,'é­”æ³•è³¦äºˆ'),(1393,7,192,'è£½ä½œå¬å–šäººå¶'),(1394,7,193,'éŠé‡‘è¡“'),(1395,7,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(1396,7,195,'ç”Ÿå‘½ä¹‹æº'),(1397,7,196,'æ¿ç”²ç²¾é€š'),(1398,7,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(1399,7,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(1400,7,201,'æ¥µé€Ÿæˆé•·'),(1401,7,210,'å¼·åŒ– - æš´åŠ›æŠ“å–'),(1402,7,211,'å¼·åŒ– - è£‚çŸ³ç ´å¤©'),(1403,7,212,'æ™ºåŠ›ä¹‹æº'),(1404,7,213,'ç²¾ç¥žä¹‹æº'),(1405,7,214,'å‘½ä¸­ç²¾é€š'),(1406,7,215,'å›žé¿ç²¾é€š'),(1407,7,216,'HPæ¢å¾©ç²¾é€š'),(1408,7,217,'MPæ¢å¾©ç²¾é€š'),(1409,7,218,'å±¬æ€§æ”»æ“Šç²¾é€š'),(1410,7,219,'å±¬æ€§æŠ—æ€§ç²¾é€š'),(1411,7,233,'çƒˆç«å¼·è¸¢'),(1412,7,234,'çƒˆç«å¼·æ‹³'),(1413,7,238,'æ¥µæ­¦éœ¸çš‡è¸¢'),(1414,8,1,'é­”æ³•æ—‹é¢¨'),(1415,8,2,'é›·å…‰éˆ'),(1416,8,3,'å†°æ™¶å¢œ'),(1417,8,4,'æš—åŸŸæ“´å¼µ'),(1418,8,5,'å±¬æ€§è®Šæ›'),(1419,8,6,'åœ°ç‚Ž'),(1420,8,7,'å†°éœœä¹‹å¾‘'),(1421,8,8,'å†°é­„åŠ'),(1422,8,9,'å¹½å†¥ç«'),(1423,8,10,'ç ´å†°é£›åˆƒ'),(1424,8,11,'æ—‹ç‚Žç ´'),(1425,8,12,'å†°é­„éŒ˜æ“Š'),(1426,8,13,'å†°é¾æ—‹èˆž'),(1427,8,14,'å†°æ™¶ä¹‹æµ´'),(1428,8,15,'æ—‹å†°ç©¿åˆº'),(1429,8,16,'å†°é­„ä¹‹å¼“'),(1430,8,17,'æ“’æ‹¿æŽŒ'),(1431,8,18,'é­”æ³•ç‚®'),(1432,8,19,'å…ƒç´ ç’°ç¹ž'),(1433,8,20,'çž¬ç§»'),(1434,8,21,'å¯’å†°é€£æ§'),(1435,8,22,'ç™¼ç¾'),(1436,8,23,'å†°é­„æ—‹æ§'),(1437,8,24,'é»‘æš—ç¦åŸŸ'),(1438,8,25,'é­”çƒé€£å°„'),(1439,8,26,'é­”æ³•å†°çƒ'),(1440,8,27,'æ—‹ç«ç›¾'),(1441,8,28,'é­”åŠ›ç‡ƒç‡’'),(1442,8,29,'é›·å…‰å±éšœ'),(1443,8,30,'å…ƒç´ è½Ÿç‚¸'),(1444,8,31,'å¯’å†°ä¹‹å¢ƒ'),(1445,8,32,'æ¥µå†°ç¶»æ”¾'),(1446,8,33,'ä¸æ­»ä¹‹èº«'),(1447,8,34,'å±¬æ€§ä¿è­·'),(1448,8,35,'å†°ä¹‹å°'),(1449,8,36,'å…ƒç´ çˆ†ç ´å¸«å¸ƒç”²å°ˆç²¾'),(1450,8,37,'å†°çµå¸«çš®ç”²å°ˆç²¾'),(1451,8,48,'åƒæ—‹å†°è¼ªç ´'),(1452,8,49,'å¹»é­”å››é‡å¥'),(1453,8,50,'å†°å°å¥§ç¾©'),(1454,8,51,'å…ƒç´ å–šé†’'),(1455,8,57,'æ°¸ç½ªå†°ç„'),(1456,8,60,'å†°æ·©ç ´'),(1457,8,61,'å…ƒç´ æ¿ƒç¸®çƒ'),(1458,8,62,'å…ƒç´ å¹»æ»…'),(1459,8,63,'åƒé‡Œå†°å°'),(1460,8,70,'æœ«æ—¥æ¹®æ»…'),(1461,8,91,'æŽƒæŠŠæŽŒæ¡'),(1462,8,92,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(1463,8,169,'åŽè·³'),(1464,8,172,'è¼•ç”²ç²¾é€š'),(1465,8,173,'é‡ç”²ç²¾é€š'),(1466,8,174,'åŸºç¤Žç²¾é€š'),(1467,8,175,'èºç¿”'),(1468,8,176,'é å¤è¨˜æ†¶'),(1469,8,177,'æŠ•æ“²ç²¾é€š'),(1470,8,178,'ç‰©ç†èƒŒæ“Š'),(1471,8,179,'ç‰©å“åˆ†è§£'),(1472,8,180,'ä¸å±ˆæ„å¿—'),(1473,8,181,'ç²¾å·¥'),(1474,8,182,'ç´¡ç¹”'),(1475,8,183,'æ©Ÿæ¢°'),(1476,8,184,'ç…‰é‡‘'),(1477,8,185,'çš®ç”²ç²¾é€š'),(1478,8,186,'ç‰©ç†æš´æ“Š'),(1479,8,187,'å¸ƒç”²ç²¾é€š'),(1480,8,188,'é­”æ³•æš´æ“Š'),(1481,8,189,'é­”æ³•èƒŒæ“Š'),(1482,8,190,'å—èº«è¹²ä¼'),(1483,8,191,'é­”æ³•è³¦äºˆ'),(1484,8,192,'è£½ä½œå¬å–šäººå¶'),(1485,8,193,'éŠé‡‘è¡“'),(1486,8,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(1487,8,195,'ç”Ÿå‘½ä¹‹æº'),(1488,8,196,'æ¿ç”²ç²¾é€š'),(1489,8,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(1490,8,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(1491,8,201,'æ¥µé€Ÿæˆé•·'),(1492,8,211,'å¼·åŒ– - é­”æ³•æ—‹é¢¨'),(1493,8,212,'å¼·åŒ– - é›·å…‰éˆ'),(1494,8,213,'å¼·åŒ– - å†°æ™¶å¢œ'),(1495,8,214,'å¼·åŒ– - æš—åŸŸæ“´å¼µ'),(1496,8,216,'å¼·åŒ– - åœ°ç‚Ž'),(1497,8,217,'å¼·åŒ– - å†°éœœä¹‹å¾‘'),(1498,8,218,'å¼·åŒ– - å†°é­„åŠ'),(1499,8,219,'å¼·åŒ– - å¹½å†¥ç«'),(1500,8,220,'å¼·åŒ– - ç ´å†°é£›åˆƒ'),(1501,8,221,'å¼·åŒ– - æ—‹ç‚Žç ´'),(1502,8,222,'å¼·åŒ– - å†°é­„éŒ˜æ“Š'),(1503,8,223,'å¼·åŒ– - å†°é¾æ—‹èˆž'),(1504,8,224,'å¼·åŒ– - å†°æ™¶ä¹‹æµ´'),(1505,8,225,'å¼·åŒ– - æ—‹å†°ç©¿åˆº'),(1506,8,226,'å¼·åŒ– - å†°é­„ä¹‹å¼“'),(1507,8,227,'å¼·åŒ– - æ“’æ‹¿æŽŒ'),(1508,8,228,'å¼·åŒ– - é­”æ³•ç‚®'),(1509,8,229,'å¼·åŒ– - å…ƒç´ ç’°ç¹ž'),(1510,8,231,'å¼·åŒ– - å¯’å†°é€£æ§'),(1511,8,233,'å¼·åŒ– - å†°é­„æ—‹æ§'),(1512,8,234,'å¼·åŒ– - é»‘æš—ç¦åŸŸ'),(1513,8,235,'å¼·åŒ– - é­”çƒé€£å°„'),(1514,8,236,'å¼·åŒ– - é­”æ³•å†°çƒ'),(1515,8,237,'å¼·åŒ– - æ—‹ç«ç›¾'),(1516,8,239,'å¼·åŒ– - é›·å…‰å±éšœ'),(1517,8,240,'å¼·åŒ– - å…ƒç´ è½Ÿç‚¸'),(1518,8,241,'å¼·åŒ– - å¯’å†°ä¹‹å¢ƒ'),(1519,8,242,'å¼·åŒ– - æ¥µå†°ç¶»æ”¾'),(1520,9,1,'æ ¼æ“‹'),(1521,9,2,'å†¥ç‚Ž'),(1522,9,3,'è‡ªå‹•æ ¼æ“‹'),(1523,9,4,'é»‘æš—å…‰åŠç²¾é€š'),(1524,9,5,'é¬¼æ–¬'),(1525,9,6,'å™¬éˆé¬¼æ–¬'),(1526,9,7,'é€†è½‰åæ“Š'),(1527,9,8,'è¿…æ·ä¹‹åˆ‡'),(1528,9,9,'æ‹–å¼•ä¹‹åŠ'),(1529,9,10,'å¼·åˆ¶ - æ³¢å‹•åŠ'),(1530,9,11,'é€£çªåˆº'),(1531,9,12,'æš—å½±åŠç²¾é€š'),(1532,9,13,'é»‘æš—ä¹‹åˆ€ç²¾é€š'),(1533,9,14,'é»‘æš—å¤§åˆ€ç²¾é€š'),(1534,9,15,'é»‘æš—éˆå™¨ç²¾é€š'),(1535,9,16,'éŠ€å…‰è½åˆƒ'),(1536,9,17,'ç©ºä¸­é€£æ–¬'),(1537,9,18,'æ†‘ä¾'),(1538,9,19,'è¡€æ°£å–šé†’'),(1539,9,20,'æ³¢æµª'),(1540,9,21,'å†°åˆƒ Â· æ³¢å‹•åŠ'),(1541,9,22,'çˆ†ç‚Ž Â· æ³¢å‹•åŠ'),(1542,9,23,'å—œè¡€'),(1543,9,24,'æš—å½±çˆ†ç‚¸'),(1544,9,25,'é¬¼ç¥ž Â· å¡è´Š'),(1545,9,26,'å¼·åˆ¶ - ä¸‰æ®µæ–¬'),(1546,9,27,'æ­¦å™¨å¥§ç¾©'),(1547,9,28,'å–æ¶ˆ - é¬¼æ–¬'),(1548,9,29,'æš—ä¹‹è¦ªå’Œ'),(1549,9,30,'æš—æœˆé™è‡¨'),(1550,9,31,'æš—ä¹‹è¡åˆº'),(1551,9,32,'æ³¢å‹•çˆ†ç™¼'),(1552,9,33,'å…‰åŠæŽŒæ¡'),(1553,9,34,'æ­»äº¡æŠ—æ‹’'),(1554,9,35,'å°å°è§£é™¤'),(1555,9,36,'å†°éœœä¹‹è–©äºž'),(1556,9,37,'ç–¾å½±æ‰‹'),(1557,9,38,'ç ´æ¥µå…µåˆƒ'),(1558,9,39,'æ­¦å™¨ç¯€åˆ¶'),(1559,9,40,'æš´èµ°'),(1560,9,41,'é¬¼ç¥ž Â· ä¾µè•æ™®æˆ¾è’™'),(1561,9,42,'é¬¼é£Ÿ'),(1562,9,43,'è‰ä¸Šé£›'),(1563,9,44,'é»‘æš—é™è‡¨'),(1564,9,45,'å¼·åˆ¶ - æ ¼æ“‹'),(1565,9,46,'ä¸Šå‡'),(1566,9,47,'æ³¢å‹•åˆ»å°'),(1567,9,48,'å¼·åˆ¶ - ä¸ŠæŒ‘'),(1568,9,49,'åŽè·³æ–¬'),(1569,9,50,'å·¨å¤§æ³¢æµª'),(1570,9,51,'ä¿®ç¾…é‚ªå…‰æ–¬'),(1571,9,52,'æ®ºæ„æ³¢å‹•'),(1572,9,53,'æŒ«æŠ˜æ„å¿—'),(1573,9,54,'å–æ¶ˆ - å—œé­‚ä¹‹æ‰‹'),(1574,9,55,'æ®ºæ°£æ„ŸçŸ¥'),(1575,9,56,'ç‹‚æˆ°å£«é‡ç”²å°ˆç²¾'),(1576,9,57,'éœ‡å‹•æ³¢'),(1577,9,58,'ç¾½ç¿¼çŒ›æ“Š'),(1578,9,59,'å¼·åˆ¶ - è£‚æ³¢æ–¬'),(1579,9,60,'çž¬é–“ç æ“Š'),(1580,9,61,'é˜¿ä¿®ç¾…æ¿ç”²å°ˆç²¾'),(1581,9,62,'ç„¡é›™æ³¢'),(1582,9,63,'è¡€æ°£æ—ºç››'),(1583,9,64,'æš—åå­—'),(1584,9,65,'è·³èºç²‰ç¢Ž'),(1585,9,66,'å¼·åˆ¶ - å´©å±±æ“Š'),(1586,9,67,'è£ Â· é¬¼åŠè¡“'),(1587,9,68,'æš—å½±çŒ›æ“Š'),(1588,9,69,'å¼·åˆ¶ - ç ´è»å‡é¾æ“Š'),(1589,9,70,'å¼·åˆ¶ - æ€’æ°£çˆ†ç™¼'),(1590,9,71,'å¼·åˆ¶ - é¬¼å°ç '),(1591,9,72,'çž¬å½±æ–¬'),(1592,9,73,'å¹»ä¹‹æ“Š'),(1593,9,74,'æ—‹æ³¢'),(1594,9,75,'é¬¼ç¥ž Â· ç˜Ÿç–«ç¾…ç…ž'),(1595,9,76,'è¡€ä¹‹ç‹‚æš´'),(1596,9,77,'æ—‹è½‰ä¹‹æ“Š'),(1597,9,78,'å¼·åˆ¶ - åå­—æ–¬'),(1598,9,79,'æš—å½±ç‹‚å˜¯'),(1599,9,80,'æ»¿æœˆæ–¬'),(1600,9,81,'æš—å½±è£‚åœ°æ–¬'),(1601,9,82,'é»‘è‰²ç«ç„°ä¹‹åŠ'),(1602,9,83,'å¼·åˆ¶ - æœˆå…‰æ–¬'),(1603,9,84,'é¬¼ç¥ž Â· æ®˜å½±å‡±è³ˆ'),(1604,9,85,'é­”ç„è¡€å‰Ž'),(1605,9,86,'æ¥µ Â· é¬¼åŠè¡“ (æš´é¢¨å¼)'),(1606,9,87,'æ€–æ‹‰ä¿®'),(1607,9,88,'æ³¢å‹•çœ¼ : çµ‚çµæŠ€'),(1608,9,89,'ææ‡¼å…‰ç’°'),(1609,9,90,'é®®è¡€ä¹‹æ†¶'),(1610,9,91,'æ¥µ Â· é¬¼åŠè¡“ (æ–¬éµå¼)'),(1611,9,92,'å¿ƒçœ¼'),(1612,9,93,'å™¬é­‚è€…å¸ƒç”²å°ˆç²¾'),(1613,9,94,'åŠé­‚è¼•ç”²å°ˆç²¾'),(1614,9,95,'å¢“ç¢‘ä¸‰çµ•é™£'),(1615,9,96,'é¬¼ç¥ž Â· å†°æ™¶è–©äºž'),(1616,9,97,'ç ´ç©ºæ‹”åˆ€æ–¬'),(1617,9,98,'ç ´è»æ–¬é¾æ“Š'),(1618,9,99,'æ¥µç‚Ž Â· è£‚æ³¢åŠ'),(1619,9,100,'æ¥µå†° Â· è£‚æ³¢åŠ'),(1620,9,101,'è¡€æ°£çˆ†ç™¼'),(1621,9,102,'æ»…é­‚ä¹‹æ‰‹'),(1622,9,103,'é»‘æš—ä¹‹åŠ'),(1623,9,104,'å¼·åˆ¶ - è¡€æ°£ä¹‹åˆƒ'),(1624,9,105,'æµå¿ƒ'),(1625,9,106,'å¼·åˆ¶ - æµå¿ƒ'),(1626,9,107,'ç©¿åˆºæ”»æ“Š'),(1627,9,108,'åå½ˆçˆ†è£‚'),(1628,9,109,'æµå¿ƒ : å‡'),(1629,9,110,'æµå¿ƒ : ç‹‚'),(1630,9,111,'éž­æ“Š'),(1631,9,112,'ä¸‰é‡åˆºæ“Š'),(1632,9,113,'å¼·åˆ¶ - é¬¼å½±éž­'),(1633,9,114,'å¼·åˆ¶ - é¬¼å½±ä¸‰æ“ŠåŠ'),(1634,9,115,'å¼·åŒ– - é¬¼åŠéž­'),(1635,9,116,'å¼·åŒ– - é¬¼å½±ä¸‰æ“ŠåŠ'),(1636,9,117,'é»‘æš—æ³¢æµª'),(1637,9,118,'å·çˆ¾æ’¢0'),(1638,9,119,'å·çˆ¾æ’¢1'),(1639,9,120,'å·çˆ¾æ’¢2'),(1640,9,121,'å·çˆ¾æ’¢3'),(1641,9,122,'å·çˆ¾æ’¢4'),(1642,9,123,'å·çˆ¾æ’¢5'),(1643,9,139,'å¼·åŒ– - è¡€æ°£å–šé†’'),(1644,9,140,'å¼·åŒ– - åœ°è£‚ Â· æ³¢å‹•åŠ'),(1645,9,141,'å¼·åŒ– - åå­—æ–¬'),(1646,9,142,'å¼·åŒ– - é¬¼æ–¬'),(1647,9,143,'å¼·åŒ– - ä¸‰æ®µæ–¬'),(1648,9,144,'å¼·åŒ– - é€†è½‰åæ“Š'),(1649,9,145,'å¼·åŒ– - è‡ªå‹•æ ¼æ“‹'),(1650,9,146,'å¼·åŒ– - é¬¼ç¥ž Â· ä¾µè•æ™®æˆ'),(1651,9,147,'å¼·åŒ– - æ†‘ä¾'),(1652,9,148,'å¼·åŒ– - æ­»äº¡æŠ—æ‹’'),(1653,9,149,'å¼·åŒ– - æš´èµ°'),(1654,9,150,'å¼·åŒ– - æ®ºæ„æ³¢å‹•'),(1655,9,151,'å¼·åŒ– - æ³¢å‹•åˆ»å°'),(1656,9,152,'å¼·åŒ– - çŒ›é¾æ–·ç©ºæ–¬'),(1657,9,153,'å¼·åŒ– - éŠ€å…‰è½åˆƒ'),(1658,9,154,'å¼·åŒ– - æ‹”åˆ€æ–¬'),(1659,9,155,'å¼·åŒ– - æœˆå…‰æ–¬'),(1660,9,156,'å¼·åŒ– - é¬¼ç¥ž Â· ç˜Ÿç–«ç¾…ç…'),(1661,9,157,'å¼·åŒ– - å´©å±±æ“Š'),(1662,9,158,'å¼·åŒ– - å—œé­‚å°é­”æ–¬'),(1663,9,159,'å¼·åŒ– - è£‚æ³¢æ–¬'),(1664,9,160,'å¼·åŒ– - é¬¼å°ç '),(1665,9,161,'å¼·åŒ– - åŸºç¤Žç²¾é€š'),(1666,9,162,'å¼·åŒ– - é€£çªåˆº'),(1667,9,163,'å¼·åŒ– - æ ¼æª”'),(1668,9,164,'å¼·åŒ– - é¬¼ç¥ž Â· å¡è´Š'),(1669,9,165,'å¼·åŒ– - å—œé­‚ä¹‹æ‰‹'),(1670,9,166,'å¼·åŒ– - æ€’æ°£çˆ†ç™¼'),(1671,9,167,'å¼·åŒ– - å´©å±±è£‚åœ°æ–¬'),(1672,9,168,'å¼·åŒ– - è¡€æ°£ä¹‹åˆƒ'),(1673,9,169,'åŽè·³'),(1674,9,170,'å–æ¶ˆ - åŽè·³'),(1675,9,171,'å–æ¶ˆ - æŠ•æ“²'),(1676,9,172,'è¼•ç”²ç²¾é€š'),(1677,9,173,'é‡ç”²ç²¾é€š'),(1678,9,174,'åŸºç¤Žç²¾é€š'),(1679,9,175,'èºç¿”'),(1680,9,176,'é å¤è¨˜æ†¶'),(1681,9,177,'æŠ•æ“²ç²¾é€š'),(1682,9,178,'ç‰©ç†èƒŒæ“Š'),(1683,9,179,'ç‰©å“åˆ†è§£'),(1684,9,180,'ä¸å±ˆæ„å¿—'),(1685,9,181,'ç²¾å·¥'),(1686,9,182,'ç´¡ç¹”'),(1687,9,183,'æ©Ÿæ¢°'),(1688,9,184,'ç…‰é‡‘'),(1689,9,185,'çš®ç”²ç²¾é€š'),(1690,9,186,'ç‰©ç†æš´æ“Š'),(1691,9,187,'å¸ƒç”²ç²¾é€š'),(1692,9,188,'é­”æ³•æš´æ“Š'),(1693,9,189,'é­”æ³•èƒŒæ“Š'),(1694,9,190,'å—èº«è¹²ä¼'),(1695,9,191,'é­”æ³•è³¦äºˆ'),(1696,9,192,'è£½ä½œå¬å–šäººå¶'),(1697,9,193,'éŠé‡‘è¡“'),(1698,9,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(1699,9,195,'ç”Ÿå‘½ä¹‹æº'),(1700,9,196,'æ¿ç”²ç²¾é€š'),(1701,9,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(1702,9,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(1703,9,201,'æ¥µé€Ÿæˆé•·'),(1704,9,210,'å¼·åŒ– - æ³¢å‹•çˆ†ç™¼'),(1705,9,211,'å¼·åŒ– - é‚ªå…‰æ–¬'),(1706,9,212,'å¼·åŒ– - çˆ†ç‚Žæ³¢å‹•åŠ'),(1707,9,213,'å¼·åŒ– - ç„¡é›™æ³¢'),(1708,9,214,'å¼·åŒ– - ä¸å‹•æ˜ŽçŽ‹é™£'),(1709,9,215,'å¼·åŒ– - ä¸ŠæŒ‘'),(1710,9,216,'å†°åˆƒ Â· æ³¢å‹•åŠ'),(1711,9,217,'å¼·åŒ– - å¹»å½±åŠèˆž'),(1712,9,218,'å¼·åŒ– - ç ´è»å‡é¾æ“Š'),(1713,9,219,'å¼·åŒ– - æµå¿ƒ : åˆº'),(1714,9,220,'å¼·åŒ– - æµå¿ƒ : èº'),(1715,9,221,'å¼·åŒ– - æµå¿ƒ : å‡'),(1716,9,224,'å¼·åŒ– -å†°éœœä¹‹è–©äºž'),(1717,9,225,'å¼·åŒ– - æ­»äº¡å¢“ç¢‘'),(1718,9,226,'å¼·åŒ– - é¬¼å½±é–ƒ'),(1719,9,227,'å¼·åŒ– - é¬¼ç¥ž Â· å†¥ç‚Žé¬¼ç¥'),(1720,9,228,'å¼·åŒ– - é¬¼å°ç '),(1721,9,232,'é‚ªå½±å‡é¾æ–¬'),(1722,9,233,'è¶…æ™‚ç©ºç¢Žè£‚'),(1723,10,91,'æŽƒæŠŠæŽŒæ¡'),(1724,10,131,'çƒˆç«ç‡ŽåŽŸ'),(1725,10,132,'çƒˆç„°é¢¶é¢¨'),(1726,10,133,'ç†¾ç‚Žæ˜Ÿéš•'),(1727,10,134,'å†°éœœä¹‹çƒ'),(1728,10,135,'æ¥µå†°è­·ç›¾'),(1729,10,136,'å†°å¤©éœ‡åœ°'),(1730,10,137,'ç¥žä¹‹æ‰‹'),(1731,10,138,'æ¨¹ä¹‹å±éšœ'),(1732,10,169,'åŽè·³'),(1733,10,170,'å–æ¶ˆ - åŽè·³'),(1734,10,171,'å–æ¶ˆ - æŠ•æ“²'),(1735,10,172,'è¼•ç”²ç²¾é€š'),(1736,10,173,'é‡ç”²ç²¾é€š'),(1737,10,174,'åŸºç¤Žç²¾é€š'),(1738,10,175,'èºç¿”'),(1739,10,176,'é å¤è¨˜æ†¶'),(1740,10,177,'æŠ•æ“²ç²¾é€š'),(1741,10,178,'ç‰©ç†èƒŒæ“Š'),(1742,10,179,'ç‰©å“åˆ†è§£'),(1743,10,180,'ä¸å±ˆæ„å¿—'),(1744,10,181,'ç²¾å·¥'),(1745,10,182,'ç´¡ç¹”'),(1746,10,183,'æ©Ÿæ¢°'),(1747,10,184,'ç…‰é‡‘'),(1748,10,185,'çš®ç”²ç²¾é€š'),(1749,10,186,'ç‰©ç†æš´æ“Š'),(1750,10,187,'å¸ƒç”²ç²¾é€š'),(1751,10,188,'é­”æ³•æš´æ“Š'),(1752,10,189,'é­”æ³•èƒŒæ“Š'),(1753,10,190,'å—èº«è¹²ä¼'),(1754,10,191,'é­”æ³•è³¦äºˆ'),(1755,10,192,'è£½ä½œå¬å–šäººå¶'),(1756,10,193,'éŠé‡‘è¡“'),(1757,10,194,'é–‹å•Ÿåˆ†è§£å•†åº—'),(1758,10,195,'ç”Ÿå‘½ä¹‹æº'),(1759,10,196,'æ¿ç”²ç²¾é€š'),(1760,10,197,'æ”»æ“Šé¡žåž‹è½‰æ›'),(1761,10,200,'å…¬æœƒ : å¢žåŠ è§’è‰²å±¬æ€§'),(1762,10,201,'æ¥µé€Ÿæˆé•·'),(1763,10,248,'è¶…èƒ½æ—‹é¢¨æ³¢'),(1764,10,249,'é¢¨æš´æ¼©æ¸¦'),(1765,10,250,'çƒˆç‚Žç³»'),(1766,10,251,'å¯’å†°ç³»'),(1767,10,252,'æŽ§åˆ¶ç³»'),(1768,10,253,'å®ˆè­·ç³»'),(1769,10,254,'é¢¨æš´ç³»');
DROP TABLE IF EXISTS `skill_lethe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_lethe` (
  `m_id` int(11) NOT NULL default '0',
  `charac_no` int(11) NOT NULL default '0',
  `skill_slot` blob NOT NULL,
  `flag` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`m_id`,`charac_no`),
  KEY `indx` USING BTREE (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store` (
  `charac_no` int(11) NOT NULL default '0',
  `store` blob NOT NULL,
  `use_doll` tinyint(1) default '0',
  PRIMARY KEY  (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `tmp_charac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_charac` (
  `m_id` int(11) NOT NULL default '0',
  `charac_no` int(11) NOT NULL default '0',
  PRIMARY KEY  (`m_id`,`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `user_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_items` (
  `ui_id` int(11) NOT NULL auto_increment,
  `charac_no` int(11) NOT NULL default '0',
  `slot` int(11) NOT NULL default '0',
  `it_id` int(11) NOT NULL default '0',
  `expire_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `obtain_from` tinyint(4) default NULL,
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ipg_agency_no` varchar(32) NOT NULL default '',
  `ability_no` tinyint(4) NOT NULL default '0',
  `stat` tinyint(3) unsigned NOT NULL default '0',
  `clear_avatar_id` int(11) NOT NULL default '0',
  `jewel_socket` blob NOT NULL,
  `item_lock_key` tinyint(3) unsigned NOT NULL default '0',
  `to_ipg_agency_no` varchar(32) NOT NULL default '',
  `m_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `hidden_option` smallint(5) unsigned NOT NULL default '0',
  `emblem_endurance` smallint(5) unsigned NOT NULL default '0',
  `color1` int(11) default '0',
  `color2` int(11) default '0',
  `trade_restrict` int(11) default '0',
  PRIMARY KEY  (`ui_id`),
  KEY `idxm_id` USING BTREE (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `user_items_del`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_items_del` (
  `sdate` date NOT NULL default '0000-00-00',
  `ui_id` int(11) NOT NULL default '0',
  `charac_no` int(11) NOT NULL default '0',
  `slot` int(11) NOT NULL default '0',
  `it_id` int(11) NOT NULL default '0',
  `expire_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `obtain_from` tinyint(4) default NULL,
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ipg_agency_no` varchar(32) NOT NULL default '',
  `ability_no` tinyint(4) NOT NULL default '0',
  `stat` tinyint(3) unsigned NOT NULL default '0',
  `clear_avatar_id` int(11) NOT NULL default '0',
  `jewel_socket` varbinary(30) NOT NULL default '',
  `item_lock_key` tinyint(4) NOT NULL default '0',
  `to_ipg_agency_no` varchar(32) NOT NULL default '',
  `m_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `hidden_option` smallint(5) unsigned NOT NULL default '0',
  `emblem_endurance` smallint(5) unsigned NOT NULL default '0',
  `color1` smallint(5) unsigned NOT NULL default '0',
  `color2` smallint(5) unsigned NOT NULL default '0',
  `trade_restrict` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sdate`,`ui_id`),
  KEY `idxm_id` USING BTREE (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `user_items_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_items_history` (
  `ui_id` int(11) NOT NULL auto_increment,
  `charac_no` int(11) NOT NULL default '0',
  `slot` int(11) NOT NULL default '0',
  `it_id` int(11) NOT NULL default '0',
  `expire_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `obtain_from` tinyint(4) default NULL,
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ipg_agency_no` varchar(32) NOT NULL default '',
  `ability_no` tinyint(4) NOT NULL default '0',
  `stat` tinyint(3) unsigned NOT NULL default '0',
  `clear_avatar_id` int(11) NOT NULL default '0',
  `jewel_socket` blob NOT NULL,
  `item_lock_key` tinyint(3) unsigned NOT NULL default '0',
  `to_ipg_agency_no` varchar(32) NOT NULL default '',
  `m_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `hidden_option` smallint(5) unsigned NOT NULL default '0',
  `emblem_endurance` smallint(5) unsigned NOT NULL default '0',
  `color1` int(11) default '0',
  `color2` int(11) default '0',
  `trade_restrict` int(11) default '0',
  PRIMARY KEY  (`ui_id`),
  KEY `idxm_id` USING BTREE (`charac_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `user_items_work`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_items_work` (
  `ui_id` int(11) NOT NULL default '0',
  `charac_no` int(11) NOT NULL default '0',
  `slot` int(11) NOT NULL default '0',
  `it_id` int(11) NOT NULL default '0',
  `expire_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `obtain_from` tinyint(4) default NULL,
  `reg_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ipg_agency_no` varchar(32) NOT NULL default '',
  `ability_no` tinyint(4) NOT NULL default '0',
  `stat` tinyint(3) unsigned NOT NULL default '0',
  `clear_avatar_id` int(11) NOT NULL default '0',
  `jewel_socket` blob NOT NULL,
  `item_lock_key` tinyint(3) unsigned NOT NULL default '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `village_attack_dungeon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_attack_dungeon` (
  `occ_date` date NOT NULL default '0000-00-00',
  `charac_no` int(10) unsigned NOT NULL default '0',
  `attack_count` tinyint(3) unsigned NOT NULL default '0',
  `revenge_dungeon` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`occ_date`,`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DROP TABLE IF EXISTS `village_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `village_ticket` (
  `charac_no` int(10) unsigned NOT NULL default '0',
  `village` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`charac_no`,`village`),
  KEY `idx_village_charac` USING BTREE (`charac_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

